import { Injectable } from '@angular/core'; 

import { HttpClient } from '@angular/common/http'; 


import { BehaviorSubject, catchError, Observable, of } from 'rxjs'; 

@Injectable({ 

  providedIn: 'root' 

}) 

export class AuthService { 

  private baseUrl = 'http://localhost:9090'; 

  private _selectedProducts = new BehaviorSubject<any[]>([]); 

  selectedProducts$ = this._selectedProducts.asObservable(); 

 

  // Two-way binding compatible getter/setter 

  get selectedProducts(): any[] { 

    return this._selectedProducts.value; 

  } 

 

  set selectedProducts(products: any[]) { 

    this._selectedProducts.next(products); 

  } 

  constructor(private http:HttpClient){} 

 

  loginType: 'user' | 'admin' | null = null; 

 

  setLoginType(type: 'user' | 'admin') { 

    this.loginType = type; 

    localStorage.setItem('loginType', type);  // Add this line 

  } 

   

  getLoginType(): 'user' | 'admin' | null { 

    // First check memory, else read from localStorage 

    if (!this.loginType) { 

      const stored = localStorage.getItem('loginType'); 

      if (stored === 'user' || stored === 'admin') { 

        this.loginType = stored; 

      } 

    } 

    return this.loginType; 

  } 

 

  login(credentials: {username:string;password:string}): Observable<any> { 

    return this.http.post(`${this.baseUrl}/auth/login`,credentials); 

  } 

  getToken():string |null{ 

    if (typeof window !== 'undefined') { 

      return localStorage.getItem('token'); 

    } 

    return null; 

  } 

  getRole():string |null{ 

    return localStorage.getItem('role'); 

  } 

 

  logout():void{ 

    localStorage.clear(); 

  } 

  isLoggedIn():boolean{ 

    return !!this.getToken(); 

  } 

  register(data:any):Observable<any>{ 

    return this.http.post(`${this.baseUrl}/auth/register`,data); 

  } 

  addProduct(data:any):Observable<any>{ 

    return this.http.post(`${this.baseUrl}/product/addProduct`,data); 

  } 

  getCategories(): Observable<any[]> { 

    return this.http.get<any[]>(`${this.baseUrl}/category/getCategories`).pipe( 

      catchError((error) => { 

        console.error('Failed to load categories:', error); 

        return of([]); 

      }) 

    ); 

  } 

  addCategory(data: any): Observable<any> { 

    return this.http.post(`${this.baseUrl}/category/addCategory`, data).pipe( 

      catchError((error) => { 

        console.error('Failed to add category:', error); 

        return of(null);  

      }) 

    ); 

  } 

  getProducts(): Observable<any[]> { 

    return this.http.get<any[]>(`${this.baseUrl}/product/getProducts`).pipe( 

      catchError((error) => { 

        console.error('Failed to fetch products:', error); 

        return of([]); 

      }) 

    ); 

  } 

  getCustomerDetails() { 

    return this.http.get<any>(`${this.baseUrl}/customer/getCustomerDetails`); 

  } 

   

  updateCustomer(data: any) { 

    return this.http.put<any>(`${this.baseUrl}/customer/update`, data); 

  } 

  getFirstName(): Observable<any> { 

    console.log("calling api"); 

    return this.http.get<any>(`${this.baseUrl}/customer/getFirstName`).pipe( 

      catchError((error) => { 

        console.log("calling done"); 

        console.error('Error fetching first name:', error); 

        return of(null); // return a fallback value to prevent errors 

      }) 

    ); 

  } 

  deleteCategory(id: number): Observable<any> { 

    return this.http.post(`${this.baseUrl}/category/deleteCategory?id=${id}`, null).pipe( 

      catchError((error) => { 

        console.error('Failed to delete category:', error); 

        return of(null); 

      }) 

    ); 

  } 

  deleteProduct(productId: number): Observable<any> { 

    return this.http.post(`${this.baseUrl}/product/deleteProduct?id=${productId}`, null).pipe( 

      catchError((error) => { 

        console.error('Failed to delete product:', error); 

        return of(null); 

      }) 

    ); 

  } 

   

  updateProduct(product: any): Observable<any> { 

    return this.http.post(`${this.baseUrl}/product/updateProduct`, product).pipe( 

      catchError((error) => { 

        console.error('Failed to update product:', error); 

        return of(null); 

      }) 

    ); 

  } 

  updateUserRole(customerId: number, role: string) { 

    return this.http.put(`${this.baseUrl}/customer/updateRole/${customerId}`, { role }); 

  } 

  getAllCustomers() { 

    return this.http.get<any>(`${this.baseUrl}/customer/getall`); 

  } 

 

  getCartByCustomerId(customerId: any): Observable<any> { 

    return this.http.get(`${this.baseUrl}/cart/getCart/${customerId}`); 

  } 

 

 

getCartItems(cartId: number): Observable<any> { 

  return this.http.get(`${this.baseUrl}/cart-items/getByCart/${cartId}`); 

} 

addCartItem(cartItem: any): Observable<any> { 

  return this.http.post(`${this.baseUrl}/cart-items/add`, cartItem); 

} 

deleteCartItem(productId: number, cartId: number): Observable<any> { 

  return this.http.post(`${this.baseUrl}/cart-items/delete?cartId=${cartId}&productId=${productId}`, {}); 

} 

getProductById(productId: number): Observable<any> { 

  return this.http.get(`${this.baseUrl}/product/getProduct/${productId}`).pipe( 

    catchError((error) => { 

      console.error(`Failed to fetch product with ID ${productId}:`, error); 

      return of(null); 

    }) 

  ); 

 

} 

addReview(review: any): Observable<any> { 

  return this.http.post(`${this.baseUrl}/reviews/addReview`, review); 

} 

 

getReviewsByProduct(productId: number): Observable<any> { 

  return this.http.get(`${this.baseUrl}/reviews/product/${productId}`); 

} 

createOrder(order: any): Observable<any> { 

  return this.http.post(`${this.baseUrl}/orders/create`, order); 

} 

 

// getOrderById(orderId: number): Observable<any> { 

//   return this.http.get(`${this.baseUrl}/orders/getById/${orderId}`); 

// } 

 

getOrdersByCustomerId(customerId: number): Observable<any> { 

  return this.http.get(`${this.baseUrl}/orders/getByCustomer/${customerId}`); 

} 

 

updateOrderStatus(orderId: number, status: string): Observable<any> { 

  return this.http.post(`${this.baseUrl}/orders/updateStatus?orderId=${orderId}&status=${status}`, {}); 

} 

addOrderItem(orderItem: any): Observable<any> { 

  return this.http.post(`${this.baseUrl}/order-items/add`, orderItem); 

} 

 

getOrderItemsByOrderId(orderId: number): Observable<any> { 

  return this.http.get(`${this.baseUrl}/order-items/getByOrder/${orderId}`); 

} 

 

// updateOrderItemQuantity(orderDetailId: number, quantity: number): Observable<any> { 

//   return this.http.post(`${this.baseUrl}/order-items/updateQuantity?orderDetailId=${orderDetailId}&quantity=${quantity}`, {}); 

// } 

 

// deleteOrderItem(orderDetailId: number): Observable<any> { 

//   return this.http.delete(`${this.baseUrl}/order-items/delete/${orderDetailId}`); 

// } 

createPayment(payment: any): Observable<any> { 

  return this.http.post(`${this.baseUrl}/payment/create`, payment); 

} 

 

getPaymentByOrderId(orderId: number): Observable<any> { 

  console.log('Cancel shipping for orderId:', orderId); 

  return this.http.get(`${this.baseUrl}/payment/getByOrder/${orderId}`); 

} 

 

updatePaymentStatus(paymentId: number, status: string): Observable<any> { 

  return this.http.put(`${this.baseUrl}/payment/updateStatus?paymentId=${paymentId}&status=${status}`, {}); 

} 

addShippingAddress(shippingAddress: any): Observable<any> { 

  return this.http.post(`${this.baseUrl}/shipping/add`, shippingAddress); 

} 

 

getShippingAddressByOrderId(orderId: number): Observable<any> { 

  return this.http.get(`${this.baseUrl}/shipping/getByOrder/${orderId}`); 

} 

 

// updateShippingAddress(shippingId: number, updatedAddress: any): Observable<any> { 

//   return this.http.put(`${this.baseUrl}/shipping/update/${shippingId}`, updatedAddress); 

// } 

 

// deleteShippingAddress(shippingId: number): Observable<any> { 

//   return this.http.delete(`${this.baseUrl}/shipping/delete/${shippingId}`); 

// } 

decrementProductQuantity(productId: number, quantity: number): Observable<any> { 

  return this.http.post(`${this.baseUrl}/product/decrementProductQuantity?productId=${productId}&quantity=${quantity}`, {}).pipe( 

    catchError((error) => { 

      console.error('Failed to decrement product quantity:', error); 

      return of(null); 

    }) 

  ); 

}    

getPaymentsByCustomer(customerId: any): Observable<any> { 

  return this.http.get<any>(`${this.baseUrl}/payment/getPaymentsByCustomer/${customerId}`); 

} 

cancelShipping(orderId: number): Observable<any> { 

  console.log('Cancel shipping for orderId: in cancel ', orderId); 

  return this.http.put(`${this.baseUrl}/shipping/cancelShipping/${orderId}`, {}); 

} 

incrementProductQuantity(productId: number, quantity: number): Observable<any> { 

  return this.http.post(`${this.baseUrl}/product/incrementProductQuantity?productId=${productId}&quantity=${quantity}`, {}).pipe( 

    catchError((error) => { 

      console.error('Failed to increment product quantity:', error); 

      return of(null); 

    }) 

  ); 

}    

 

getProductCount(): Observable<number> { 

  return this.http.get<number>(`${this.baseUrl}/product/count`).pipe( 

    catchError((error) => { 

      console.error('Failed to fetch product count:', error); 

      return of(0); // fallback to 0 on error 

    }) 

  ); 

} 

 

 

 

getCustomerCount(): Observable<number> { 

  return this.http.get<number>(`${this.baseUrl}/customer/count`).pipe( 

    catchError((error) => { 

      console.error('Failed to fetch customer count:', error); 

      return of(0); // fallback to 0 on error 

    }) 

  ); 

} 

 

 

getTopSellingProducts(): Observable<any[]> { 

  return this.http.get<any[]>(`${this.baseUrl}/admin/top-selling-products`).pipe( 

    catchError((error) => { 

      console.error('Failed to fetch top selling products:', error); 

      return of([]); 

    }) 

  ); 

} 

 

 

getLowStockProducts(): Observable<string[]> { 

  return this.http.get<string[]>(`${this.baseUrl}/product/low-stock`).pipe( 

    catchError((error) => { 

      console.error('Failed to fetch low stock products:', error); 

      return of([]); 

    }) 

  ); 

} 

 

 

getSalesData(): Observable<any[]> { 

  return this.http.get<any[]>(`${this.baseUrl}/admin/sales-data`).pipe( 

    catchError((error) => { 

      console.error('Failed to fetch sales data:', error); 

      return of([]); 

    }) 

  ); 

} 

 

getCustomerGrowth(): Observable<any[]> { 

  return this.http.get<any[]>(`${this.baseUrl}/admin/customer-growth`).pipe( 

    catchError((error) => { 

      console.error('Failed to fetch customer growth data:', error); 

      return of([]); 

    }) 

  ); 

} 

getTotalOrders(): Observable<number> { 

  return this.http.get<number>(`${this.baseUrl}/orders/count`).pipe( 

    catchError((error) => { 

      console.error('Failed to fetch total orders:', error); 

      return of(0); 

    }) 

  ); 

} 

getTotalRevenue(): Observable<number> { 

  return this.http.get<number>(`${this.baseUrl}/orders/totalRevenue`).pipe( 

    catchError((error) => { 

      console.error('Failed to fetch total revenue:', error); 

      return of(0); 

    }) 

  ); 

} 

getOutOfStockProducts(): Observable<any> { 

  return this.http.get<string[]>(`${this.baseUrl}/product/out-of-stock`).pipe( 

    catchError((error) => { 

      console.error('Failed to fetch OUT OF STOCK products :', error); 

      return of(0); 

    }) 

  );; 

} 

 

 

getCustomerGrowthStats(): Observable<any> { 

   return this.http.get<any[]>(`${this.baseUrl}/customer/growth`).pipe( 

    catchError((error) => { 

      console.error('Failed to fetch Customer growth Status :', error); 

      return of(0); 

    }) 

  );; 

} 

 

getSalesOverTime(): Observable<any> { 

 return this.http.get<any[]>(`${this.baseUrl}/orders/salesOverTime`).pipe( 

  catchError((error) => { 

    console.error('Failed to fetch sales over time : ', error); 

    return of(0); 

  }) 

); 

} 

getProductsByCategory(categoryId:number){ 

  return this.http.get<any[]>(`${this.baseUrl}/product/byCategory/${categoryId}`).pipe( 

    catchError((error) => { 

      console.error('Failed to fetch products by categoryId : ', error); 

      return of(0); 

    }) 

  ); 

} 

getOrderAmountById(orderId: any): Observable<number> { 

  return this.http.get<number>(`${this.baseUrl}/orders/amount/${orderId}`); 

} 

 

getLoggedInUserEmail(): string { 

  const token = localStorage.getItem('token'); 

  if (!token) return ''; 

 

  try { 

    const payload = JSON.parse(atob(token.split('.')[1])); // decode JWT payload 

    return payload.sub || ''; // 'sub' contains the email 

  } catch (e) { 

    return ''; 

  } 

} 

 

getAllOrdersWithDetails(): Observable<any> { 

  return this.http.get(`${this.baseUrl}/orders/all-orders`).pipe( 

    catchError((error) => { 

      console.error('Failed to fetch all orders with details:', error); 

      return of([]);   

    }) 

  ); 

} 

 

} 

 