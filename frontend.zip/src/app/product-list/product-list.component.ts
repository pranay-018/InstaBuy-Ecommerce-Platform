import { Component, OnInit } from '@angular/core'; 

import { CommonModule } from '@angular/common'; 

import { AuthService } from '../services/auth.service'; 

import { Router } from '@angular/router'; 

import { AdminNavBarComponent } from "../admin-nav-bar/admin-nav-bar.component"; 

import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms'; 

import { FormsModule } from '@angular/forms'; 

import { TruncateDescriptionPipe } from '../truncate-description.pipe/truncate-description.pipe'; 

import { RouterModule } from '@angular/router'; 

import { UserNavComponent } from '../user-nav/user-nav.component'; 

 

@Component({ 

  selector: 'app-product-list', 

  standalone: true, 

  imports: [CommonModule, FormsModule, ReactiveFormsModule,UserNavComponent, AdminNavBarComponent, TruncateDescriptionPipe,RouterModule], 

  templateUrl: './product-list.component.html', 

  styleUrl: './product-list.component.scss' 

}) 

export class ProductListComponent implements OnInit { 

  products: any[] = []; 

  categories: any[] = []; 

  errorMessage = ''; 

  successMessage = ''; 

  showAddForm = false; 

  imagePreview: string | ArrayBuffer | null = null; 

  searchText: string = ''; 

  showDeleteDialog: boolean = false; 

  productToDelete: any = null; 

  showSuccessDialog: boolean = false; 

  successDialogMessage: string = ''; 

   

  isAdmin:boolean=false; 

 

  productForm: FormGroup; 

 

  constructor( 

    private authService: AuthService, 

    private router: Router, 

    private fb: FormBuilder 

  ) { 

    this.productForm = this.fb.group({ 

      productName: ['', [Validators.required, Validators.minLength(3)]], 

      productPrice: ['', [Validators.required, Validators.min(1)]], 

      productAvailability: ['', [Validators.required, Validators.min(1)]], 

      productDescription: ['', [Validators.required, Validators.minLength(10)]], 

      categoryId: ['', Validators.required], 

      base64Image: ['', Validators.required] 

    }); 

  } 

 

  ngOnInit(): void { 

    const role = localStorage.getItem('role'); 

    if(role=="ADMIN"){ 

      this.isAdmin = true; 

    } 

    else{ 

      this.isAdmin = false; 

    } 

 

    this.productForm = this.fb.group({ 

    productName: ['', Validators.required], 

    productPrice: ['', [Validators.required, Validators.min(0)]], 

    productAvailability: ['', [Validators.required, Validators.min(0)]], 

    categoryId: ['', Validators.required], 

    productDescription: ['', Validators.required], 

    base64Image: ['', Validators.required] 

  }); 

   

    this.loadProducts(); 

    this.loadCategories(); 

  } 

 

  loadProducts(): void { 

    this.authService.getProducts().subscribe({ 

      next: (data: any) => { 

        if (data && Array.isArray(data.productDtos)) { 

          this.products = data.productDtos.map((product: any) => ({ 

            ...product, 

            imageUrl: `data:image/jpeg;base64,${product.productImage}` 

          })); 

        } else { 

          this.errorMessage = 'No products found.'; 

        } 

      }, 

      error: () => { 

        this.errorMessage = 'Failed to load products. Please try again later.'; 

      } 

    }); 

  } 

   

 

  loadCategories(): void { 

    this.authService.getCategories().subscribe({ 

      next: (data: any) => this.categories = data.categoryDtos, 

      error: () => this.errorMessage = 'Failed to load categories.' 

    }); 

  } 

 

  filteredProducts(): any[] { 

    if (!this.searchText.trim()) return this.products; 

    return this.products.filter(product => 

      product.productName.toLowerCase().includes(this.searchText.toLowerCase()) 

    ); 

  } 

 

  onFileChange(event: any): void { 

    const file = event.target.files[0]; 

    if (file) { 

      const reader = new FileReader(); 

      reader.onload = () => { 

        this.imagePreview = reader.result; 

 

        // 💡 PATCH the base64 string into the form 

        this.productForm.patchValue({ 

          base64Image: (reader.result as string).split(',')[1] // remove the `data:image/...` prefix 

        }); 

      }; 

      reader.readAsDataURL(file); 

    } 

  } 

 

 

  onSubmit(): void { 

    if (this.productForm.invalid) { 

      this.productForm.markAllAsTouched(); 

      return; 

    } 

 

    const productPayload = { 

      productName: this.productForm.value.productName, 

      productPrice: this.productForm.value.productPrice, 

      productAvailability: this.productForm.value.productAvailability, 

      productDescription: this.productForm.value.productDescription, 

      categoryId: this.productForm.value.categoryId, 

      productImage: this.productForm.value.base64Image 

    }; 

 

    this.authService.addProduct(productPayload).subscribe({ 

      next: (res) => { 

        this.loadProducts(); 

        this.successMessage = "product added successfully..."; 

        this.showAddForm = false; 

        this.productForm.reset() 

        setTimeout(() => { 

          this.router.navigate(['/product-list']); 

        }, 3000) 

      }, 

      error: () => (this.errorMessage = "Add Product Failed"), 

    }) 

  } 

 

  goBack(): void { 

    this.router.navigate(['/admin-home']); 

  } 

  selectedProduct: any = null; 

  showEditDialog = false; 

 

  confirmDelete(product: any): void { 

    this.productToDelete = product; 

    this.showDeleteDialog = true; 

    document.body.classList.add('modal-open'); 

  } 

 

  cancelDelete(): void { 

    this.productToDelete = null; 

    this.showDeleteDialog = false; 

    document.body.classList.remove('modal-open'); 

  } 

 

  performDelete(): void { 

    if (!this.productToDelete) return; 

 

    this.authService.deleteProduct(this.productToDelete.productId).subscribe({ 

      next: () => { 

        this.loadProducts(); 

        this.cancelDelete(); 

        this.successDialogMessage = 'Product deleted successfully!'; 

        this.showSuccessDialog = true; 

      }, 

      error: () => { 

        this.errorMessage = 'Failed to delete product.'; 

        this.cancelDelete(); 

      } 

    }); 

  } 

 

 

  openEditDialog(product: any): void { 

    this.selectedProduct = { ...product }; 

    this.imagePreview = product.imageUrl; 

    this.productForm.patchValue({ 

      productName: product.productName, 

      productDescription: product.productDescription, 

      productPrice: product.productPrice, 

      productAvailability: product.availableQuantity, 

      categoryId: product.categoryId, 

      base64Image: product.productImage 

    }); 

    this.showEditDialog = true; 

  } 

 

  cancelEdit(): void { 

    this.showEditDialog = false; 

    this.selectedProduct = null; 

    this.productForm.reset(); 

    this.imagePreview = null; 

  } 

 

  saveChanges(): void { 

    if (this.productForm.invalid || !this.selectedProduct) return; 

   

    const updatedProduct = { 

      ...this.selectedProduct, 

      productId: this.selectedProduct.productId, 

      productName: this.productForm.value.productName, 

      productDescription: this.productForm.value.productDescription, 

      productPrice: this.productForm.value.productPrice, 

      productAvailability: this.productForm.value.productAvailability, 

      categoryId: this.productForm.value.categoryId, 

      productImage: this.productForm.value.base64Image, 

    }; 

   

    this.authService.updateProduct(updatedProduct).subscribe({ 

      next: () => { 

        this.loadProducts(); 

        this.successMessage = ''; // Optional: clear toast message 

        this.errorMessage = ''; 

        this.cancelEdit(); // close the edit modal 

        this.successDialogMessage = 'Product updated successfully!'; 

        this.showSuccessDialog = true; // show success modal 

      }, 

      error: () => { 

        this.errorMessage = 'Failed to update product.'; 

      } 

    }); 

  } 

   

 

} 
