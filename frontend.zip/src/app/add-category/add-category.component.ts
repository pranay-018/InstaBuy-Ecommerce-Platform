
import { Component, OnInit } from '@angular/core'; 

import { CommonModule } from '@angular/common'; 

import { AuthService } from '../services/auth.service'; 

import { HttpClient, HttpClientModule } from '@angular/common/http'; 

import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms'; 

import { Router } from '@angular/router'; 

import { AdminNavBarComponent } from '../admin-nav-bar/admin-nav-bar.component'; 

import { UserNavComponent } from '../user-nav/user-nav.component'; 

 

@Component({ 

  selector: 'app-category-form', 

  standalone: true, 

  imports: [CommonModule, ReactiveFormsModule, HttpClientModule,AdminNavBarComponent,UserNavComponent], 

  templateUrl: './add-category.component.html', 

  styleUrl: './add-category.component.scss' 

}) 

export class AddCategoryComponent { 

  categoryForm!: FormGroup; 

  successMessage = ''; 

  errorMessage = ''; 

  isAdmin:boolean=false; 

 

  constructor(private fb: FormBuilder, private http: HttpClient,private authService : AuthService,private router:Router) {} 

 

  ngOnInit(): void { 

    const role = localStorage.getItem('role'); 

    if(role=="ADMIN"){ 

      this.isAdmin = true; 

    } 

    else{ 

      this.isAdmin = false; 

    } 

    this.categoryForm = this.fb.group({ 

      categoryName: ['', Validators.required] 

    }); 

  } 

addCategory(): void { 

  if (this.categoryForm.invalid) { 

    this.errorMessage = 'Category name cannot be empty!'; 

    this.successMessage = ''; 

    this.autoClearMessages(); 

    return; 

  } 

 

  const payload = this.categoryForm.value; 

 

  this.authService.addCategory(payload).subscribe({ 

    next: (res) => { 

      if (res) { 

        this.successMessage = 'Category added successfully!'; 

        this.categoryForm.reset(); 

        setTimeout(() => { 

          this.router.navigate(['/category-list']); 

        }, 1000); 

      } else { 

        this.errorMessage = 'Failed to add category.'; 

      } 

      this.autoClearMessages(); 

    }, 

    error: (err) => { 

      if (err.status === 409) { 

        this.errorMessage = 'Category already exists!'; 

      } else { 

        this.errorMessage = 'Failed to add category.'; 

      } 

      this.autoClearMessages(); 

    } 

  }); 

} 

 

 

  autoClearMessages(): void { 

    setTimeout(() => { 

      this.successMessage = ''; 

      this.errorMessage = ''; 

    }, 1000); 

  } 

  goToCategoryList(): void { 

    this.router.navigate(['/category-list']); 

  } 

} 

 

