
import { Component, OnInit } from '@angular/core'; 

import { FormBuilder, FormGroup } from '@angular/forms'; 

import { AuthService } from '../services/auth.service'; 

import { CommonModule } from '@angular/common'; 

import { AdminNavBarComponent } from "../admin-nav-bar/admin-nav-bar.component"; 

import { Router } from '@angular/router'; 

import { ReactiveFormsModule,Validators } from '@angular/forms'; 

import { UserNavComponent } from '../user-nav/user-nav.component'; 

 

@Component({ 

  selector: 'app-edit-profile', 

  standalone: true, 

  imports: [ReactiveFormsModule, CommonModule, AdminNavBarComponent,UserNavComponent], 

  templateUrl: './edit-profile.component.html', 

  styleUrls: ['./edit-profile.component.css'] 

}) 

export class EditProfileComponent implements OnInit { 

  profileForm!: FormGroup; 

  customer: any; 

  isEditMode = false; 

  successMessage: string = ""; 

  loading: boolean = false; 

  isAdmin:boolean=false; 

  constructor(private fb: FormBuilder, private authService: AuthService, private router: Router) {} 

 

  ngOnInit(): void { 

    const role = localStorage.getItem('role'); 

    if(role=="ADMIN"){ 

      this.isAdmin = true; 

    } 

    else{ 

      this.isAdmin = false; 

    } 

    this.profileForm = this.fb.group({ 

      firstName: ['', Validators.required], 

      lastName: ['', Validators.required], 

      email: [{ value: '', disabled: true }, [Validators.required, Validators.email]], 

      phoneNumber: ['', [Validators.required, Validators.pattern(/^\d{10}$/)]], 

      dateOfBirth: ['', Validators.required], 

      houseNo: ['', Validators.required], 

      street: ['', Validators.required], 

      city: ['', Validators.required], 

      state: ['', Validators.required], 

      pincode: ['', [Validators.required, Validators.pattern(/^\d{6}$/)]] 

    }); 

    this.authService.getCustomerDetails().subscribe({ 

      next: (res) => { 

        this.customer = res.user; 

        this.profileForm.patchValue({ 

          firstName: this.customer.firstName, 

          lastName: this.customer.lastName, 

          email: this.customer.email, 

          phoneNumber: this.customer.phn_no, 

          dateOfBirth: this.customer.dateOfBirth, 

          houseNo: this.customer.address.house_no, 

          street: this.customer.address.street_no, 

          city: this.customer.address.city, 

          state: this.customer.address.state, 

          pincode: this.customer.address.pincode 

        }); 

        this.profileForm.disable(); 

      }, 

      error: (err) => { 

        console.error('Error loading profile:', err); 

      } 

    }); 

  } 

 

  enableEdit() { 

    this.isEditMode = true; 

    this.profileForm.enable(); 

    this.successMessage = ""; 

    this.profileForm.get('email')?.disable(); 

  } 

 

  saveChanges() { 

    if (this.profileForm.valid) { 

      const formValue = this.profileForm.value; 

      const updatedData = { 

        first_name: formValue.firstName, 

        last_name: formValue.lastName, 

        dob: formValue.dateOfBirth, 

        phn_no: Number(formValue.phoneNumber), 

        email: formValue.email, 

        addressdto: { 

          house_no: formValue.houseNo, 

          street_no: formValue.street, 

          city: formValue.city, 

          state: formValue.state, 

          pincode: Number(formValue.pincode) 

        } 

      }; 

 

      this.authService.updateCustomer(updatedData).subscribe({ 

        next: (res) => { 

          this.loading = true; 

          this.profileForm.disable(); 

          this.isEditMode = false; 

          setTimeout(() => { 

            this.successMessage = ""; 

            this.loading = false; 

          }, 3000); 

        }, 

        error: () => { 

          this.successMessage = "Failed to change the details"; 

        } 

      }); 

    } 

    this.router.navigate(['/edit-profile']) 

  } 

} 
