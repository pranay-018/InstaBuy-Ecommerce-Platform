
import { Component } from '@angular/core'; 

import { AuthService } from '../services/auth.service'; 

import { Router } from '@angular/router'; 

import { AdminNavBarComponent } from "../admin-nav-bar/admin-nav-bar.component"; 

import { CommonModule } from '@angular/common'; 

import { UserNavComponent } from '../user-nav/user-nav.component'; 

@Component({ 

  selector: 'app-admin-profile', 
standalone:true,
  imports: [AdminNavBarComponent,CommonModule,UserNavComponent], 

  templateUrl: './admin-profile.component.html', 

  styleUrl: './admin-profile.component.css' 

}) 

export class AdminProfileComponent { 

   

  isAdmin:boolean=false; 

 

  constructor(private router:Router, private authService : AuthService){} 

 

ngOnInit():void{ 

  const role = localStorage.getItem('role'); 

    if(role=="ADMIN"){ 

      this.isAdmin = true; 

    } 

    else{ 

      this.isAdmin = false; 

    } 

} 

 

  goToEditProfile() { 

    this.router.navigate(['/edit-profile']) 

  } 

 

  logout() { 

    this.router.navigate(['/login']) 

  } 

 

  goToHome(){ 

    this.router.navigate(['/admin-home']) 

  } 

 

  goToMyOrders() { 

    this.router.navigate(['/orders']); 

  } 

  goToMakeAdmin(){ 

    this.router.navigate(['/make-admin']); 

  } 

  goToMyTransactions() { 

    this.router.navigate(['/payments']); 

  } 

 

  goToAddProduct() { 

    this.router.navigate(['/add-product']) 

  } 

 

  goToAddCategory() { 

    this.router.navigate(['/add-category']) 

  } 

 

  goToListProducts() { 

    this.router.navigate(['/product-list']) 

  } 

 

  goToListCategories() { 

    this.router.navigate(['/category-list']) 

  } 

 

  goToDashboard() { 

    this.router.navigate(['/admin-dash']); 

  } 

} 

