import { Component, OnInit } from '@angular/core'; 

import { CommonModule } from '@angular/common'; 

import { Router } from '@angular/router'; 

import { UserNavComponent } from '../user-nav/user-nav.component'; 

import { AdminNavBarComponent } from '../admin-nav-bar/admin-nav-bar.component'; 

 

@Component({ 

  selector: 'app-profile', 

  standalone: true, 

  imports: [CommonModule,UserNavComponent,AdminNavBarComponent], 

  templateUrl: './profile.component.html', 

}) 

export class ProfileComponent implements OnInit{ 

  isAdmin:boolean=false; 

  constructor(private router: Router) {} 

  ngOnInit(): void { 

    const role = localStorage.getItem('role'); 

    if(role=="ADMIN"){ 

      this.isAdmin = true; 

    } 

    else{ 

      this.isAdmin = false; 

    } 

  } 

 

  goToMyCart(): void { 

    this.router.navigate(['/cart']) 

  } 

 

  goToMyOrders(): void { 

    this.router.navigate(['/orders']) 

  } 

 

  goToTransactions(): void { 

    this.router.navigate(['/payments']) 

  } 

 

  editUserDetails(): void { 

    this.router.navigate(['/edit-profile']) 

  } 

 

  logout(): void { 

    this.router.navigate(['login']); 

  } 

} 
