
import { Component, OnInit } from '@angular/core'; 

import { CommonModule } from '@angular/common'; 

import { RouterModule } from '@angular/router'; 

import { AuthService } from '../services/auth.service'; 

import { AdminNavBarComponent } from '../admin-nav-bar/admin-nav-bar.component'; 

import { UserNavComponent } from '../user-nav/user-nav.component'; 

import { FormsModule } from '@angular/forms'; 

 

interface OrderDTO { 

  orderId: number; 

  userId: number; 

  orderStatus: string; 

  totalAmount: number; 

  createdAt: string; 

  orderItemDtos: OrderItemDTO[]; 

} 

 

interface OrderItemDTO { 

  orderDetailId: number; 

  orderId: number; 

  productId: number; 

  quantity: number; 

  price: number; 

} 

 

interface ProductDTO { 

  productId: number; 

  productName: string; 

  productDescription: string; 

  productPrice: number; 

  availableQuantity: number; 

  productImage: string; 

} 

 

interface CustomerDTO { 

  customerId: number; 

  firstName: string; 

  lastName: string; 

} 

 

@Component({ 

  selector: 'app-all-orders', 

  standalone: true, 

  imports: [CommonModule, RouterModule, AdminNavBarComponent, UserNavComponent, FormsModule], 

  templateUrl: './all-orders.component.html', 

  styleUrls: ['./all-orders.component.css'] 

}) 

export class AllOrdersComponent implements OnInit { 

  allOrders: any[] = []; 

  isLoading: boolean = true; 

  error: string | null = null; 

  isAdmin: boolean = false; 

 

  searchTerm: string = ''; 

  sortColumn: string = ''; 

  sortDirection: 'asc' | 'desc' = 'asc'; 

 

  constructor(private authService: AuthService) {} 

 

  ngOnInit(): void { 

    this.isAdmin = localStorage.getItem('role') === 'ADMIN'; 

    this.fetchOrders(); 

  } 

 

  fetchOrders(): void { 

    this.authService.getAllOrdersWithDetails().subscribe({ 

      next: (res) => { 

        this.allOrders = res.orderDtos || []; 

        this.isLoading = false; 

      }, 

      error: (err) => { 

        this.error = 'Failed to load orders'; 

        this.isLoading = false; 

      } 

    }); 

  } 

 

  get filteredOrders(): any[] { 

    let filtered = this.allOrders.filter((order) => { 

      const term = this.searchTerm.toLowerCase(); 

      return ( 

        order.orderId.toString().includes(term) || 

        order.orderStatus?.toLowerCase().includes(term) || 

        order.customerDto?.firstName?.toLowerCase().includes(term) || 

        order.customerDto?.lastName?.toLowerCase().includes(term) 

      ); 

    }); 

 

    if (this.sortColumn) { 

      filtered.sort((a, b) => { 

        const valA = this.resolveNestedField(a, this.sortColumn); 

        const valB = this.resolveNestedField(b, this.sortColumn); 

 

        if (this.sortColumn === 'createdAt') { 

          // Compare dates for 'createdAt' 

          const dateA = new Date(valA); 

          const dateB = new Date(valB); 

          return this.sortDirection === 'asc' ? dateA.getTime() - dateB.getTime() : dateB.getTime() - dateA.getTime(); 

        } 

        return valA > valB ? 1 : valA < valB ? -1 : 0; 

      }); 

    } 

    return filtered; 

  } 

 

  search(): void { 

    this.filteredOrders; 

  } 

 

  sortBy(column: string): void { 

    if (this.sortColumn === column) { 

      this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc'; 

    } else { 

      this.sortColumn = column; 

      this.sortDirection = 'asc'; 

    } 

  } 

 

  resolveNestedField(obj: any, path: string): any { 

    const fields = path.split('.'); 

    let result = obj; 

    for (let field of fields) { 

      result = result ? result[field] : undefined; 

    } 

    return result; 

  } 

 

  getTotalAmount(): number { 

    return this.filteredOrders.reduce((sum, order) => sum + order.totalAmount, 0); 

  } 

} 

