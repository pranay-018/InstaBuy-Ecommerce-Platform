
import { Component, OnInit, ViewChild } from '@angular/core'; 

import { CommonModule, DatePipe } from '@angular/common'; 

import { HttpClient, HttpHeaders } from '@angular/common/http'; 

import { forkJoin, Observable } from 'rxjs'; 

import { Router } from '@angular/router'; 

import { MatTableDataSource, MatTableModule } from '@angular/material/table'; 

import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator'; 

import { MatSort, MatSortModule } from '@angular/material/sort'; 

import { MatFormFieldModule } from '@angular/material/form-field'; 

import { MatInputModule } from '@angular/material/input'; 

import { MatProgressSpinnerModule } from '@angular/material/progress-spinner'; 

import { MatBadgeModule } from '@angular/material/badge'; 

import { MatIconModule } from '@angular/material/icon'; 

import { MatCardModule } from '@angular/material/card'; 

import { MatButtonModule } from '@angular/material/button'; 

 

import { FormsModule } from '@angular/forms'; 

import { AdminNavBarComponent } from '../admin-nav-bar/admin-nav-bar.component'; 

import { AuthService } from '../services/auth.service'; 

import { UserNavComponent } from '../user-nav/user-nav.component'; 

 

 

interface OrderDTO { 

  orderId: number; 

  userId: number; 

  orderStatus: string; 

  totalAmount: number; 

  createdAt: string; 

  orderItemDtos: OrderItemDTO[]; 

} 

  

interface OrderItemDTO { 

  orderDetailId: number; 

  orderId: number; 

  productId: number; 

  quantity: number; 

  price: number; 

} 

  

interface ProductDTO { 

  productId: number; 

  productName: string; 

  productDescription: string; 

  productPrice: number; 

  availableQuantity: number; 

  productImage: string; 

} 

interface CustomerDTO { 

  customerId: number; 

  firstName: string; 

  lastName: string; 

  

} 

 

@Component({ 

  selector: 'app-all-transaction', 

  standalone: true, 

  imports: [ 

    CommonModule, 

    DatePipe, 

    FormsModule, 

    AdminNavBarComponent, 

    MatTableModule, 

    MatPaginatorModule, 

    MatSortModule, 

    MatFormFieldModule, 

    MatInputModule, 

    MatProgressSpinnerModule, 

    MatBadgeModule, 

    MatIconModule, 

    MatCardModule, 

    MatButtonModule, 

    UserNavComponent, 

  ], 

  templateUrl: './all-transaction.component.html', 

}) 

export class AllTransactionComponent implements OnInit { 

   payments: any[] = []; 

  filteredPayments: any[] = []; 

  totalAmount: number = 0; 

  searchText: string = ''; 

  sortColumn: string = ''; 

  sortDirection: 'asc' | 'desc' = 'asc'; 

   isAdmin: boolean = false; 

 

  constructor(private http: HttpClient, private authService: AuthService) {} 

 

  ngOnInit(): void { 

    this.isAdmin = localStorage.getItem('role') === 'ADMIN'; 

    this.fetchPayments(); 

  } 

 

  fetchPayments(): void { 

    this.http.get<any>('http://localhost:9090/payment/getAllPayments').subscribe(res => { 

      const paymentList = res.paymentDtos || []; 

 

      const amountRequests: Observable<number>[] = paymentList.map((payment: any) => 

  this.authService.getOrderAmountById(payment.orderId) 

); 

 

 

      forkJoin(amountRequests).subscribe((amounts: number[]) => { 

        this.payments = paymentList.map((payment: any, index: number) => ({ 

          paymentId: payment.paymentId, 

          orderId: payment.orderId, 

          customerName: payment.customerDto.firstName + ' ' + payment.customerDto.lastName, 

          paymentStatus: payment.paymentStatus, 

          paymentMethod: payment.paymentMethod, 

          paymentDate: new Date(payment.paymentDate), 

          amount: amounts[index] 

        })); 

 

        this.filteredPayments = [...this.payments]; 

        this.calculateTotal(); 

      }); 

    }); 

  } 

 

  calculateTotal(): void { 

    this.totalAmount = this.filteredPayments.reduce((sum, payment) => sum + payment.amount, 0); 

  } 

 

  search(): void { 

    const term = this.searchText.toLowerCase(); 

    this.filteredPayments = this.payments.filter(payment => 

      Object.values(payment).some(value => 

        String(value).toLowerCase().includes(term) 

      ) 

    ); 

    this.calculateTotal(); 

  } 

 

  sort(column: string): void { 

    if (this.sortColumn === column) { 

      this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc'; 

    } else { 

      this.sortColumn = column; 

      this.sortDirection = 'asc'; 

    } 

 

    this.filteredPayments.sort((a, b) => { 

      const valA = a[column]; 

      const valB = b[column]; 

      if (valA < valB) return this.sortDirection === 'asc' ? -1 : 1; 

      if (valA > valB) return this.sortDirection === 'asc' ? 1 : -1; 

      return 0; 

    }); 

  } 

  } 
