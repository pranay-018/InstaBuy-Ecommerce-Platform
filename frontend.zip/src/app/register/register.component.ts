
import { Component } from '@angular/core'; 

import { AuthService } from '../services/auth.service'; 

import { Router, RouterModule } from '@angular/router'; 

import { CommonModule } from '@angular/common'; 

import { FormsModule,NgForm } from '@angular/forms'; 

 

@Component({ 

  selector: 'app-register', 

  standalone:true, 

  imports: [CommonModule,RouterModule,FormsModule], 

  templateUrl: './register.component.html', 

  styleUrl: './register.component.scss' 

}) 

export class RegisterComponent { 

  isNumber: boolean = false; 

  isSymbol: boolean = false; 

  isUppercase: boolean = false; 

  isMinLength: boolean = false; 

  isAllPasswordValid: boolean = false; 

 

checkPasswordRequirements() { 

  const pwd = this.password || ''; 

  this.isNumber = /[0-9]/.test(pwd); 

  this.isSymbol = /[^A-Za-z0-9]/.test(pwd); 

  this.isUppercase = /[A-Z]/.test(pwd); 

  this.isMinLength = pwd.length >= 6; 

 

  this.isAllPasswordValid = this.isNumber && this.isSymbol && this.isUppercase && this.isMinLength; 

} 

  firstName: string = ''; 

  lastName: string = ''; 

  dob: string = ''; 

  phone: string = ''; 

  email: string = ''; 

  password: string = ''; 

  confirmPassword: string = ''; 

  houseNumber: string = ''; 

  street: string = ''; 

  city: string = ''; 

  state: string = ''; 

  pincode: string = ''; 

  isSubmitting: boolean = false; 

  validationErrors: string[] = []; 

  successMessage: string = '';  

  address:any; 

  constructor(public authService: AuthService, private router: Router) {} 

 

  registerAction(registerForm: NgForm) { 

    this.validationErrors = []; // Reset validation errors 

   

    if (!registerForm.valid) { 

      this.validationErrors.push('Please fill in all required fields.'); 

      return; 

    } 

   

    // Validate custom fields 

 

     

    if (!this.isPhoneValid()) { 

      this.validationErrors.push('Phone Number must be exactly 10 digits.'); 

    } 

   

    if (!this.isPincodeValid()) { 

      this.validationErrors.push('Pincode must be exactly 6 digits.'); 

    } 

   

    if (this.isPasswordMismatch()) { 

      this.validationErrors.push('Passwords do not match.'); 

    } 

   

    // If any validation error, prevent form submission 

    if (this.validationErrors.length > 0) { 

      return; 

    } 

   

    this.isSubmitting = true; 

   

    const payload = { 

      first_name: this.firstName, 

      last_name: this.lastName, 

      dob: this.dob, 

      phn_no: this.phone, 

      email: this.email, 

      password: this.password, 

      addressdto: { 

        house_no: this.houseNumber, 

        street_no: this.street, 

        city: this.city, 

        state: this.state, 

        pincode: this.pincode, 

      } 

    }; 

   

    this.authService.register(payload).subscribe({ 

      next: (res) => { 

        this.successMessage = "Registration successful! Redirecting to login..."; 

        setTimeout(() => { 

          this.router.navigate(['/login']); 

        }, 3000); 

      }, 

      error: (err) => { 

        this.validationErrors.push('Registration failed. Please try again.'); 

        this.isSubmitting = false; 

      } 

    }); 

  } 

   

 

  // Validate if password and confirm password match 

  isPasswordMismatch(): boolean { 

    return this.password !== this.confirmPassword && this.password.length > 0 && this.confirmPassword.length > 0; 

  } 

 

  // Validate if phone number is exactly 10 digits 

  isPhoneValid(): boolean { 

    return /^\d{10}$/.test(this.phone); 

  } 

 

  // Validate if pincode is 6 digits long 

  isPincodeValid(): boolean { 

    return /^\d{6}$/.test(this.pincode); 

  } 

} 
