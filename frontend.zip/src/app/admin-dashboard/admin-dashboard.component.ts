
import { Component, OnInit } from '@angular/core'; 

import { CommonModule } from '@angular/common'; 

import { AdminNavBarComponent } from "../admin-nav-bar/admin-nav-bar.component"; 

import { NgxChartsModule } from '@swimlane/ngx-charts'; 

import { Color, ScaleType } from '@swimlane/ngx-charts'; 

import { AuthService } from '../services/auth.service'; 

import { FormsModule } from '@angular/forms'; 

import { Router } from '@angular/router'; 

import { HttpHeaders } from '@angular/common/http'; 

import { UserNavComponent } from '../user-nav/user-nav.component'; 

@Component({ 

 

  selector: 'app-admin-dashboard', 

  standalone: true, 

  imports: [CommonModule,UserNavComponent, AdminNavBarComponent, NgxChartsModule,FormsModule], 

  templateUrl: './admin-dashboard.component.html', 

  styleUrl: './admin-dashboard.component.css' 

}) 

export class AdminDashboardComponent implements OnInit { 

 

  totalRevenue: number = 0; 

  totalProducts: number = 0; 

  totalCustomers: number = 0; 

  totalOrders: number = 0; 

  isDarkMode = false; 

 

   

  isAdmin:boolean=false; 

 

  lowStockProducts: string[] = []; 

  outOfStockProducts: string[] = []; 

  customerGrowth: any[] = []; 

  salesOverTimeData: any[] = []; 

   

  colorScheme: Color = { 

    name: 'customScheme', 

    selectable: true, 

    group: ScaleType.Ordinal, 

    domain: ['#5AA454', '#A10A28', '#C7B42C', '#AAAAAA'] 

  }; 

 

  constructor(private authService: AuthService,private router: Router) {} 

  ngOnInit(): void { 

    const role = localStorage.getItem('role'); 

    if(role=="ADMIN"){ 

      this.isAdmin = true; 

    } 

    else{ 

      this.isAdmin = false; 

    } 

    this.loadProductCount(); 

    this.loadCustomerCount(); 

    this.loadTotalOrders(); 

    this.loadTotalRevenue(); 

    this.loadLowStockProducts(); 

    this.loadOutOfStockProducts(); 

    this.loadCustomerGrowthStats(); 

    this.loadSalesOverTime(); 

  } 

   

  loadProductCount(): void { 

    this.authService.getProductCount().subscribe({ 

      next: (count: number) => { 

        this.totalProducts = count; 

      }, 

      error: (err: any) => { 

        console.error('Error fetching product count:', err); 

      } 

    }); 

  } 

  

  loadCustomerCount(): void { 

    this.authService.getCustomerCount().subscribe({ 

      next: (count: number) => { 

        this.totalCustomers = count; 

      }, 

      error: (err: any) => { 

        console.error('Error fetching customer count:', err); 

      } 

    }); 

  } 

   

  loadTotalOrders(): void { 

    this.authService.getTotalOrders().subscribe({ 

      next: (count: number) => { 

        this.totalOrders = count; 

      }, 

      error: (err: any) => { 

        console.error('Error fetching total orders:', err); 

      } 

    }); 

  } 

   

  loadTotalRevenue(): void { 

    this.authService.getTotalRevenue().subscribe({ 

      next: (revenue: number) => { 

        this.totalRevenue = revenue; 

      }, 

      error: (err: any) => { 

        console.error('Error fetching total revenue:', err); 

      } 

    }); 

  } 

   

  loadLowStockProducts(): void { 

    this.authService.getLowStockProducts().subscribe({ 

      next: (data: string[]) => { 

        this.lowStockProducts = data; 

      }, 

      error: (err) => { 

        console.error('Error loading low stock products:', err); 

      } 

    }); 

  } 

 

  loadOutOfStockProducts(): void { 

    this.authService.getOutOfStockProducts().subscribe({ 

      next: (data: string[]) => { 

        this.outOfStockProducts = data;  // Populate the list 

      }, 

      error: (err) => { 

        console.error('Error loading out-of-stock products:', err); 

      } 

    }); 

  } 

 

 

   

  loadSalesOverTime(): void { 

    this.authService.getSalesOverTime().subscribe({ 

      next: (data: any[]) => { 

        this.processSalesOverTime(data); 

      }, 

      error: (err) => { 

        console.error('Error fetching sales over time:', err); 

      } 

    }); 

  } 

 

  processSalesOverTime(data: any[]): void { 

    const yearlySalesMap = new Map<string, number>(); 

   

    data.forEach(entry => { 

      const year = new Date(entry.date).getFullYear().toString(); 

      const currentSales = yearlySalesMap.get(year) || 0; 

      yearlySalesMap.set(year, currentSales + entry.sales); 

    }); 

   

    this.salesOverTimeData = Array.from(yearlySalesMap.entries()).map(([year, sales]) => ({ 

      name: year, 

      value: sales 

    })); 

  } 

 

 

 

 

   

  loadCustomerGrowthStats(): void { 

    this.authService.getCustomerGrowthStats().subscribe({ 

      next: (data: any[]) => { 

        this.processCustomerGrowthData(data); 

console.log('Processed growth series:', this.customerGrowth); 

 

      }, 

      error: (err) => { 

        console.error('Error fetching customer growth stats:', err); 

      } 

    }); 

  } 

  

  processCustomerGrowthData(data: any[]): void { 

    const yearlyMap = new Map<string, number>(); 

   

    data.forEach(item => { 

      const year = new Date(item.createdAt).getFullYear().toString(); 

      const prevCount = yearlyMap.get(year) || 0; 

      yearlyMap.set(year, prevCount + item.count); 

    }); 

   

    const series = Array.from(yearlyMap.entries()).map(([year, count]) => ({ 

      name: year, 

      value: count 

    })); 

   

    this.customerGrowth = [ 

      { 

        name: 'New Customers', 

        series 

      } 

    ]; 

  } 

 

  goToCategories() { 

    this.router.navigate(['/category-list']); 

  } 

  goToListProducts() { 

    this.router.navigate(['/product-list']); 

  } 

 goToManageCustomers() { 

  this.router.navigate(['/make-admin']); 

} 

 goToAllTransactions(){ 

    this.router.navigate(['/all-transaction']); 

  } 

} 
