import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { TruncateDescriptionPipe } from '../truncate-description.pipe/truncate-description.pipe';
import { RouterModule } from '@angular/router';
import { UserNavComponent } from '../user-nav/user-nav.component';
import { AdminNavBarComponent } from '../admin-nav-bar/admin-nav-bar.component';

@Component({
  selector: 'app-admin-home',
  standalone: true,
  imports: [CommonModule, TruncateDescriptionPipe, RouterModule, UserNavComponent, AdminNavBarComponent],
  templateUrl: './admin-home.component.html',
  styleUrls: ['./admin-home.component.css']  // <-- fixed from styleUrl to styleUrls
})
export class AdminHomeComponent implements OnInit {

  isAdmin: boolean = false;
  filteredProducts: any[] = [];

  averageRatings: { [productId: number]: number } = {}; // Example property

  ngOnInit() {
    // Example role check (customize this logic as needed)
    const role = localStorage.getItem('role');
    this.isAdmin = role === 'admin';

    // Initialize or fetch filtered products
    this.filteredProducts = []; // replace with real data fetching logic
  }

  onCategorySelected(event: any) {
    console.log('Category selected:', event);
    // Add filtering logic here
  }

  onSearch(event: any) {
    console.log('Search event:', event);
    // Add search/filter logic here
  }

  resetProductList() {
    console.log('Resetting product list');
    // Reset filteredProducts to full product list or empty
    this.filteredProducts = [];
  }

  goToListProducts() {
    console.log('Navigating to list products');
    // Navigation logic here
  }

  goToCategories() {
    console.log('Navigating to categories');
    // Navigation logic here
  }

  goToManageCustomers() {
    console.log('Navigating to manage customers');
    // Navigation logic here
  }

  goToManageOrders() {
    console.log('Navigating to manage orders');
    // Navigation logic here
  }

  goTransactions() {
    console.log('Navigating to transactions');
    // Navigation logic here
  }

  isInCart(productId: number): boolean {
    // Example implementation
    return false;
  }

  toggleCart(productId: number) {
    console.log('Toggling cart for product', productId);
    // Add cart toggling logic here
  }

  buyNow(product: any) {
    console.log('Buying product now:', product);
    // Add buy now logic here
  }
}
