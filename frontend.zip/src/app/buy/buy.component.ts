
import { CommonModule } from '@angular/common'; 

import { Component, OnInit } from '@angular/core'; 

import { FormsModule } from '@angular/forms'; 

import { Router } from '@angular/router'; 

import { AdminNavBarComponent } from '../admin-nav-bar/admin-nav-bar.component'; 

import { AuthService } from '../services/auth.service'; 

import { UserNavComponent } from '../user-nav/user-nav.component'; 

 

interface Product { 

  productId: number; 

  productName: string; 

  productDescription: string; 

  productPrice: number; 

  quantity: number; 

  productImage: string; 

  availableQuantity: number; 

} 

 

@Component({ 

  selector: 'app-buy', 

  standalone: true, 

  imports: [CommonModule, FormsModule, AdminNavBarComponent,UserNavComponent], 

  templateUrl: './buy.component.html', 

  styleUrls: ['./buy.component.css'] 

}) 

export class BuyComponent implements OnInit { 

  products: Product[] = []; 

  paymentMethod: string = ''; 

  loading = false; 

 

  customerId: any; 

 

  // Payment details 

  upiId: string = ''; 

  cardNumber: string = ''; 

  expiryDate: string = ''; 

  cvv: string = ''; 

 

  // Shipping details 

  name: string = ''; 

  phnNo: number | null = null; 

  hno: string = ''; 

  street: number | null = null; 

  city: string = ''; 

  state: string = ''; 

  pincode: number | null = null; 

  isAdmin:boolean=false; 

 

  constructor(private router: Router, private authService: AuthService) {} 

 

  ngOnInit(): void { 

    const role = localStorage.getItem('role'); 

    if(role=="ADMIN"){ 

      this.isAdmin = true; 

    } 

    else{ 

      this.isAdmin = false; 

    } 

    this.authService.selectedProducts$.subscribe((products) => { 

      this.products = products; 

      if (!products || products.length === 0) { 

        this.router.navigate(['/cart']); 

      } 

      this.products.forEach(product => { 

        if (!product.quantity || product.quantity < 1) { 

          product.quantity = 1; 

        } 

      }); 

    }); 

 

    this.authService.getCustomerDetails().subscribe((res: any) => { 

      const user = res.user; 

      this.customerId = user.customerID; 

      if (user) { 

        this.name = user.firstName + ' ' + user.lastName || ''; 

        this.phnNo = user.phn_no || null; 

 

        const address = user.address; 

        if (address) { 

          this.hno = address.house_no || ''; 

          this.street = address.street_no || null; 

          this.city = address.city || ''; 

          this.state = address.state || ''; 

          this.pincode = address.pincode || null; 

        } 

      } 

    }); 

  } 

 

  selectPaymentMethod(method: string): void { 

    this.paymentMethod = method; 

  } 

 

  placeOrder(): void { 

    if ( 

      this.name && this.phnNo && this.hno && 

      this.street !== null && this.city && this.state && 

      this.pincode !== null && this.paymentMethod 

    ) { 

      this.loading = true; 

   

      const totalAmount = this.products.reduce((sum, p) => sum + (p.productPrice * (p.quantity || 1)), 0); 

      console.log("this is user ID : "+this.customerId) 

      const orderDto = { 

        userId: this.customerId, 

        orderStatus: 'PLACED', 

        totalAmount: totalAmount, 

      }; 

   

      this.authService.createOrder(orderDto).subscribe({ 

        next: (orderRes: any) => { 

          console.log(orderRes); 

          const orderId = orderRes.orderDto?.orderId; 

          this.products.forEach(product => { 

            const item = { 

              orderId: orderId, 

              productId: product.productId, 

              quantity: product.quantity, 

              price: product.productPrice 

            }; 

            this.authService.addOrderItem(item).subscribe(); 

             

            // Decrement product quantity after order placement 

            if(!product.quantity){ 

              product.quantity = 1; 

            } 

            this.authService.decrementProductQuantity(product.productId, product.quantity).subscribe({ 

              next: (decrementRes) => { 

                console.log(`Product ID ${product.productId} quantity decremented successfully.`); 

              }, 

              error: (err) => { 

                console.error(`Failed to decrement product quantity for Product ID ${product.productId}:`, err); 

              } 

            }); 

          }); 

   

          // Payment 

          const paymentStatus = this.paymentMethod === 'COD' ? 'Pending' : 'Completed'; 

          const paymentDto = { 

            orderId: orderId, 

            paymentMethod: this.paymentMethod, 

            paymentStatus: paymentStatus, 

          }; 

          this.authService.createPayment(paymentDto).subscribe(); 

   

          // Shipping 

          const shippingDto = { 

            orderId: orderId, 

            name: this.name, 

            phnNo: this.phnNo, 

            hno: this.hno, 

            street: this.street, 

            city: this.city, 

            state: this.state, 

            pincode: this.pincode 

          }; 

          this.authService.addShippingAddress(shippingDto).subscribe(() => { 

            this.loading = false;   

            // Remove the purchased items from the cart after successful order placement 

            this.removePurchasedItemsFromCart(); 

            this.router.navigate(['/orders']); 

            // Optionally clear cart if necessary 

            // this.authService.clearCart(); 

            // this.router.navigate(['/order-success']); 

          }); 

        }, 

        error: (err) => { 

          this.loading = false; 

          console.error('Order placement failed:', err); 

          alert('Failed to place order. Please try again.'); 

        } 

      }); 

    } else { 

      alert('Please fill in all required fields!'); 

    } 

  } 

   // Method to remove purchased items from the cart 

  removePurchasedItemsFromCart(): void { 

    if (this.customerId) { 

      // Fetch the cart ID by customerId 

      this.authService.getCartByCustomerId(this.customerId).subscribe({ 

        next: (cartRes) => { 

          const cartId = cartRes?.cartDto?.cartId; 

          if (cartId) { 

            // Remove each purchased product from the cartItems 

            this.products.forEach((product) => { 

              this.authService.deleteCartItem(product.productId, cartId).subscribe({ 

                next: () => { 

                  console.log(`Product ID ${product.productId} removed from cart.`); 

                }, 

                error: (err) => { 

                  console.error(`Failed to remove product ID ${product.productId} from cart: `, err); 

                } 

              }); 

            }); 

          } else { 

            console.error("Cart ID not found for the customer."); 

          } 

        }, 

        error: (err) => { 

          console.error("Failed to fetch cart:", err); 

        } 

      }); 

    } else { 

      console.error("Customer ID is not available."); 

    } 

  } 

  get totalAmount(): number { 

    return this.products.reduce((sum, p) => sum + (p.productPrice * (p.quantity || 1)), 0); 

  }   

  cancelOrder() { 

    this.router.navigate(['/orders']); 

  }   

} 

