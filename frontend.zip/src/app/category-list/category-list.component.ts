
import { Component, OnInit, AfterViewInit } from '@angular/core'; 

import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms'; 

import { CommonModule } from '@angular/common'; 

import { AuthService } from '../services/auth.service'; 

import { Router } from '@angular/router'; 

import { AdminNavBarComponent } from "../admin-nav-bar/admin-nav-bar.component"; 

import { UserNavComponent } from '../user-nav/user-nav.component'; 

 

declare var bootstrap: any; // Bootstrap JS global 

 

 

 

interface CategoryResponse { 

  status: number; 

  message: string; 

  timestamp: string; 

  categoryDtos: { categoryId: number; categoryName: string }[]; // Adjust the category structure 

} 

 

@Component({ 

  selector: 'app-category-list', 

  standalone: true, 

  imports: [CommonModule,UserNavComponent, ReactiveFormsModule, AdminNavBarComponent], 

  templateUrl: './category-list.component.html', 

  styleUrl: './category-list.component.scss' 

}) 

 

 

 

export class CategoryListComponent implements OnInit, AfterViewInit { 

  categories: any[] = []; 

  errorMessage = ''; 

  successMessage = ''; 

  showAddForm = false; 

  categoryForm!: FormGroup; 

 

  categoryToDeleteId: number | null = null; 

  deleteModal: any; 

 

   

  isAdmin:boolean=false; 

 

  constructor( 

    private authService: AuthService, 

    private fb: FormBuilder, 

    private router: Router 

  ) {} 

 

  ngOnInit(): void { 

    const role = localStorage.getItem('role'); 

    if(role=="ADMIN"){ 

      this.isAdmin = true; 

    } 

    else{ 

      this.isAdmin = false; 

    } 

    this.loadCategories(); 

    this.categoryForm = this.fb.group({ 

      categoryName: ['', Validators.required] 

    }); 

  } 

 

  ngAfterViewInit(): void { 

    const modalElement = document.getElementById('deleteModal'); 

    if (modalElement) { 

      this.deleteModal = new bootstrap.Modal(modalElement); 

    } 

  } 

 

  loadCategories(): void { 

    this.authService.getCategories().subscribe({ 

      next: (data: any) => { // Use the CategoryResponse interface here 

        if (data && data.categoryDtos) { 

          this.categories = data.categoryDtos; // Extract the categoryDtos array 

        } else { 

          this.categories = []; // Handle case if no categories exist 

        } 

        console.log(data); 

      }, 

      error: () => { 

        this.errorMessage = 'Failed to load categories. Please try again later.'; 

      } 

    }); 

  } 

   

 

  goBack(): void { 

    this.router.navigate(['/admin-home']); 

  } 

 

  toggleAddCategory(): void { 

    this.showAddForm = true; 

    this.categoryForm.reset(); 

    this.successMessage = ''; 

    this.errorMessage = ''; 

  } 

 

  openDeleteModal(id: number): void { 

    this.categoryToDeleteId = id; 

    this.successMessage = ''; 

    this.errorMessage = ''; 

    this.deleteModal.show(); 

  } 

 

  confirmDelete(): void { 

    if (this.categoryToDeleteId !== null) { 

      this.authService.deleteCategory(this.categoryToDeleteId).subscribe({ 

        next: () => { 

          this.successMessage = 'Category deleted successfully.'; 

          this.loadCategories(); 

        }, 

        error: () => { 

          this.errorMessage = 'Failed to delete category.'; 

        } 

      }); 

      this.categoryToDeleteId = null; 

      this.deleteModal.hide(); 

    } 

  } 

 

  cancelAdd(): void { 

    this.showAddForm = false; 

    this.categoryForm.reset(); 

  } 

 

  submitCategory(): void { 

    if (this.categoryForm.invalid) return; 

 

    const newCat = { categoryName: this.categoryForm.value.categoryName }; 

 

    this.authService.addCategory(newCat).subscribe({ 

      next: (response) => { 

        // Handle success response 

        this.successMessage = 'Category added successfully.'; 

        this.loadCategories(); // Reload the categories list to reflect the new category 

        this.categoryForm.reset(); // Reset the form fields 

        this.showAddForm = false; // Close the add category form 

      }, 

      error: (err) => { 

        // Handle error response 

        if (err.status === 409) { 

          this.errorMessage = 'Category already exists!'; // Display a message for conflict error 

        } else { 

          this.errorMessage = 'Failed to add category. Please try again.'; // Handle other errors 

        } 

        this.autoClearMessages(); // Optional: automatically clear the messages after a few seconds 

      } 

    }); 

} 

autoClearMessages() { 

    setTimeout(() => { 

      this.successMessage = ''; 

      this.errorMessage = ''; 

    }, 5000); // Clears messages after 5 seconds 

} 

 

 

} 
