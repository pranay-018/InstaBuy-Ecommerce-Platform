
import { Component, EventEmitter, Output } from '@angular/core'; 

import { Router } from '@angular/router'; 

import { AuthService } from '../services/auth.service'; 

import { CommonModule } from '@angular/common'; 

import { FormsModule } from '@angular/forms'; 

 

@Component({ 

  selector: 'app-usernav', 
  standalone:true,

  imports: [CommonModule,FormsModule], 

  templateUrl: './user-nav.component.html', 

  styleUrl: './user-nav.component.css' 

}) 

export class UserNavComponent { 

  searchQuery: string = ''; 

  firstName: string = ''; 

  categories: any[] = []; 

  showCategoriesDropdown = false; 

  showProfileDropdown = false; 

  products :any = [] ; 

  @Output() searchEvent = new EventEmitter<string>(); 

  @Output() categorySelected = new EventEmitter<number>(); 

  @Output() resetProducts = new EventEmitter<void>(); 

  constructor(private router: Router, private authService: AuthService) {} 

   

  ngOnInit(): void { 

    console.log('In ONIT Nav bar'); 

    this.authService.getFirstName().subscribe( 

      (response: { user: { firstName: string; }; }) => { 

        if (response && response.user && response.user.firstName) { 

          this.firstName = response.user.firstName; 

        } else { 

          console.error('Invalid response structure:', response); 

          this.firstName = 'Error loading name'; 

        } 

      }, 

      (error: any) => { 

        console.error('Error fetching first name:', error); 

        this.firstName = 'Error loading name'; 

      } 

    ); 

  } 

   

onSearchChange() { 

      this.searchEvent.emit(this.searchQuery); 

    } 

   

  selectCategory(categoryId: number) { 

    this.hideCategoriesDropdown(); 

    this.router.navigate(['/category', categoryId]);  

  } 

  // Categories Dropdown 

  onCategoriesHover() { 

    this.showCategoriesDropdown = true; 

 

    if (this.categories.length === 0) { 

      this.authService.getCategories().subscribe( 

        (response:any) => { 

          this.categories = response.categoryDtos; 

        }, 

        (error: any) => { 

          console.error('Failed to fetch categories:', error); 

        } 

      ); 

    } 

  } 

 

  hideCategoriesDropdown() { 

    this.showCategoriesDropdown = false; 

  } 

 

  // Profile Dropdown 

  onProfileHover() { 

    this.showProfileDropdown = true; 

  } 

 

  hideProfileDropdown() { 

    this.showProfileDropdown = false; 

  } 

 

  // Navigation methods 

  navigateToHome() { 

    if (this.router.url === '/user-home') { 

      // If already on /user-home, manually emit reset 

      this.resetProducts.emit(); 

    } else { 

      // Navigate and reset will happen via ngOnInit in the component 

      this.router.navigate(['/user-home']); 

    }} 

  

  goToCart() { 

    this.router.navigate(['/cart']); 

  } 

 

  goToCategories() { 

    this.router.navigate(['/user-category']); 

  } 

 

  goToProfile() { 

    this.router.navigate(['/profile']); 

  } 

  goToEditProfile() { 

    this.router.navigate(['/edit-profile']); 

  } 

 

  goToOrders() { 

    this.router.navigate(['/orders']); 

  } 

 

  goToTransactions() { 

    this.router.navigate(['/payments']); 

  } 

 

  goToHome(){ 

    if (this.router.url === '/user-home') { 

      // If already on /user-home, manually emit reset 

      this.resetProducts.emit(); 

    } else { 

      // Navigate and reset will happen via ngOnInit in the component 

      this.router.navigate(['/user-home']); 

    } 

  } 

  logout() { 

    this.authService.logout(); 

    this.router.navigate(['/login']); 

  } 

} 

