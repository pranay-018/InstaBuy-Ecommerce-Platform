
import { Component, OnInit } from '@angular/core'; 

import { AuthService } from '../services/auth.service'; 

import { Router } from '@angular/router'; 

import { forkJoin } from 'rxjs'; 

import { CommonModule } from '@angular/common'; 

import { AdminNavBarComponent } from '../admin-nav-bar/admin-nav-bar.component'; 

import { RouterModule } from '@angular/router'; 

import { UserNavComponent } from '../user-nav/user-nav.component'; 



interface RawCartItem { 

  cartItemId: number; 

  cartId: number; 

  productId: number; 

  quantity: number; 

} 



interface ProductResponse { 

  productDto: Product; 

} 



interface Product { 

  productId: number; 

  productName: string; 

  productDescription: string; 

  productPrice: number; 

  availableQuantity: number; 

  productImage: string; 

} 



@Component({ 

  selector: 'app-cart', 

  standalone: true, 

  imports: [CommonModule, AdminNavBarComponent, RouterModule, UserNavComponent], 

  templateUrl: './cart.component.html', 

  styleUrls: ['./cart.component.css'] 

}) 

export class CartComponent implements OnInit { 

  cartItems: any[] = []; 

  filteredCartItems: any[] = []; 

  customerId: number | null = null; 

  cart: any; 

  loading = true; 

  isAdmin: boolean = false; 

  searchQuery: string = ''; // Holds the search input 



  constructor(private authService: AuthService, private router: Router) {} 



  ngOnInit(): void { 

    const role = localStorage.getItem('role'); 

    this.isAdmin = role === 'ADMIN' ? true : false; 



    this.authService.getCustomerDetails().subscribe({ 

      next: (customer) => { 

        this.customerId = customer?.user?.customerID; 

        if (this.customerId) { 

          this.authService.getCartByCustomerId(this.customerId).subscribe({ 

            next: (cartRes) => { 

              this.cart = cartRes?.cartDto; 

              if (this.cart) { 

                this.loadCartItems(this.cart.cartId); 

              } 

            }, 

            error: (err) => console.error('Error fetching cart:', err) 

          }); 

        } 

      }, 

      error: (err) => console.error('Error fetching customer details:', err) 

    }); 

  } 



  loadCartItems(cartId: number): void { 

    this.loading = true; 

    this.authService.getCartItems(cartId).subscribe({ 

      next: (data) => { 

        const rawItems: RawCartItem[] = data?.cartItemsDtos || []; 

        if (rawItems.length === 0) { 

          this.cartItems = []; 

          this.filteredCartItems = []; 

          this.loading = false; 

          return; 

        } 



        const productObservables = rawItems.map((item) => 

          this.authService.getProductById(item.productId) 

        ); 



        forkJoin(productObservables).subscribe({ 

          next: (responses: ProductResponse[]) => { 

            this.cartItems = rawItems.map((item, index) => ({ 

              ...item, 

              product: responses[index].productDto 

            })); 

            this.filteredCartItems = [...this.cartItems]; 

            this.loading = false; 

          }, 

          error: (err) => { 

            console.error('Error fetching products for cart items:', err); 

            this.loading = false; 

          } 

        }); 

      }, 

      error: (err) => { 

        console.error('Error loading cart items:', err); 

        this.loading = false; 

      } 

    }); 

  } 



  // Filter cart items based on the search query 

  onSearch(query: string): void { 

    this.searchQuery = query.toLowerCase(); 

    if (this.searchQuery) { 

      this.filteredCartItems = this.cartItems.filter(item => 

        item.product.productName.toLowerCase().includes(this.searchQuery) || 

        item.product.productDescription.toLowerCase().includes(this.searchQuery) 

      ); 

    } else { 

      this.filteredCartItems = [...this.cartItems]; 

    } 

  } 



  getTotal(item: any): number { 

    return item.quantity * (item.product?.productPrice || 0); 

  } 



  increment(item: any): void { 

    this.authService.getProductById(item.product?.productId).subscribe({ 

      next: (res: ProductResponse) => { 

        const product = res.productDto; 

        const availableQty = product.availableQuantity || 0; 

        item.outOfStock = false; 



        if (item.quantity < availableQty) { 

          item.quantity++; 



          const payload = { 

            cartId: this.cart?.cartId, 

            productId: item.product?.productId, 

            quantity: item.quantity, 

          }; 



          this.authService.addCartItem(payload).subscribe({ 

            next: () => {}, 

            error: (err) => console.error('Error incrementing item:', err), 

          }); 

        } else { 

          item.outOfStock = true; 

        } 

      }, 

      error: (err) => console.error('Error fetching product for increment:', err), 

    }); 

  } 



  decrement(item: any): void { 

    item.outOfStock = false; 

   

    if (item.quantity > 1) { 

      item.quantity--; 

   

      const payload = { 

        cartId: this.cart?.cartId, 

        productId: item.product?.productId, 

        quantity: item.quantity, 

      }; 

   

      this.authService.addCartItem(payload).subscribe({ 

        next: () => {}, 

        error: (err) => console.error('Error decrementing item:', err), 

      }); 

    } else { 

      this.removeFromCart(item); 

    } 

  } 

   



  removeFromCart(item: any): void { 

    this.authService.deleteCartItem(item.product?.productId, this.cart?.cartId).subscribe({ 

      next: () => { 

        this.cartItems = this.cartItems.filter( 

          (i) => i.product.productId !== item.product.productId 

        ); 

        this.filteredCartItems = this.filteredCartItems.filter( 

          (i) => i.product.productId !== item.product.productId 

        ); 

        item.outOfStock = false; 

      }, 

      error: (err) => console.error('Error removing cart item:', err), 

    }); 

  } 

   



  buyNow(item: any): void { 

    const selectedProduct = { 

      productId: item.product.productId, 

      productName: item.product.productName, 

      productDescription: item.product.productDescription, 

      productPrice: item.product.productPrice, 

      quantity: item.quantity, 

      productImage: item.product.productImage, 

    }; 

    this.authService.selectedProducts = [selectedProduct]; 

    this.router.navigate(['/buy']); 

  } 



  buyFullCart(): void { 

    const products = this.cartItems.map((item) => ({ 

      productId: item.product.productId, 

      productName: item.product.productName, 

      productDescription: item.product.productDescription, 

      productPrice: item.product.productPrice, 

      quantity: item.quantity, 

      productImage: item.product.productImage, 

    })); 

    this.authService.selectedProducts = products; 

    this.router.navigate(['/buy']); 

  } 



  getCartTotal(): number { 

    return this.cartItems.reduce((total, item) => { 

      return total + this.getTotal(item); 

    }, 0); 

  } 

} 
