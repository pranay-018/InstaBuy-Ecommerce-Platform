
import { CommonModule } from '@angular/common'; 

import { HttpClient, HttpClientModule } from '@angular/common/http'; 

import { Component, OnInit } from '@angular/core'; 

import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms'; 

import { AuthService } from '../services/auth.service'; 

import { RouterModule ,Router} from '@angular/router'; 

import { AdminNavBarComponent } from "../admin-nav-bar/admin-nav-bar.component"; 

import { UserNavComponent } from '../user-nav/user-nav.component'; 

 

@Component({ 

  selector: 'app-add-product', 
  standalone:true,

  imports: [CommonModule, ReactiveFormsModule,UserNavComponent, RouterModule, HttpClientModule, AdminNavBarComponent], 

  templateUrl: './add-product.component.html', 

  styleUrl: './add-product.component.scss' 

}) 

export class AddProductComponent implements OnInit{ 

  productForm: FormGroup; 

  successMessage: string | null = null; 

  errorMessage: string | null = null; 

  imagePreview: string | null = null; 

  isAdmin:boolean=false; 

  selectedImagePath: string | null = null; 

  categories: any[] = []; 

 

  constructor(private fb: FormBuilder, private http: HttpClient,private authService : AuthService,private router:Router) { 

    this.productForm = this.fb.group({ 

      productName: ['', [Validators.required, Validators.minLength(3)]], 

      productPrice: ['', [Validators.required, Validators.min(1)]], 

      productAvailability: ['', [Validators.required, Validators.min(1)]], 

      productDescription: ['', [Validators.required, Validators.minLength(10)]], 

      categoryId: ['', Validators.required], 

      base64Image: ['', Validators.required] 

    }); 

  } 

 

  ngOnInit(): void { 

    const role = localStorage.getItem('role'); 

    if(role=="ADMIN"){ 

      this.isAdmin = true; 

    } 

    else{ 

      this.isAdmin = false; 

    } 

    this.loadCategories(); 

  } 

 

  loadCategories(): void { 

    this.authService.getCategories().subscribe({ 

      next: (data:any) => { 

        this.categories = data.categoryDtos; 

      }, 

      error: () => { 

        this.errorMessage = 'Unable to fetch categories. Please try again later.'; 

      } 

    }); 

  } 

 

  onFileChange(event: any): void { 

    const file = event.target.files[0]; 

    if (file) { 

      const reader = new FileReader(); 

      reader.onload = () => { 

        const result = reader.result as string; 

        this.imagePreview = result; 

        const base64 = result.split(',')[1]; 

        this.productForm.patchValue({ base64Image: base64 }); 

      }; 

      reader.readAsDataURL(file); 

    } 

  } 

 

  onSubmit(): void { 

    if (this.productForm.invalid) { 

      this.productForm.markAllAsTouched(); 

      return; 

    } 

 

    const productPayload = { 

      productName: this.productForm.value.productName, 

      productPrice: this.productForm.value.productPrice, 

      productAvailability: this.productForm.value.productAvailability, 

      productDescription: this.productForm.value.productDescription, 

      categoryId: this.productForm.value.categoryId, 

      productImage: this.productForm.value.base64Image 

    }; 

    

    this.authService.addProduct(productPayload).subscribe({ 

      next:(res)=>{ 

        this.successMessage = "product added successfully..."; 

        setTimeout(()=>{ 

          this.router.navigate(['/product-list']); 

        },3000) 

      }, 

      error:()=>(this.errorMessage = "Add Product Failed"), 

    }) 

  } 

} 
