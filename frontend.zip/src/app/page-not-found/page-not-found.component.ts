
import { CommonModule } from '@angular/common'; 

import { Component } from '@angular/core'; 

import { Router } from '@angular/router'; 

import { Inject, PLATFORM_ID } from '@angular/core'; 

import { isPlatformBrowser } from '@angular/common'; 

 

 

@Component({ 

  selector: 'app-page-not-found', 

  standalone: true, 

  imports: [CommonModule], 

  templateUrl: './page-not-found.component.html', 

  styleUrl: './page-not-found.component.css' 

}) 

 

export class PageNotFoundComponent { 

  isAdmin: boolean = false; 

  loggedIn: boolean = false; 

 

  constructor(private router: Router, @Inject(PLATFORM_ID) private platformId: Object) {} 

 

  ngOnInit() { 

    if (isPlatformBrowser(this.platformId)) { 

      const role = localStorage.getItem('role'); 

      const token = localStorage.getItem('token'); 

 

      this.loggedIn = !!token; 

      if (role === 'ADMIN') { 

        this.isAdmin = true; 

      } 

    } 

  } 

 

  navigateToHome() { 

    if (!this.loggedIn) { 

      this.router.navigate(['/login']); 

    } else if (this.isAdmin) { 

      this.router.navigate(['/admin-home']); 

    } else { 

      this.router.navigate(['/user-home']); 

    } 

  } 

} 
