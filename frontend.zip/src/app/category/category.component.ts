
import { Component, OnInit } from '@angular/core'; 

import { ActivatedRoute, Route, Router } from '@angular/router'; 

import { CommonModule } from '@angular/common'; 

import { AuthService } from '../services/auth.service'; 

import { AdminNavBarComponent } from '../admin-nav-bar/admin-nav-bar.component'; 

import { UserNavComponent } from '../user-nav/user-nav.component'; 

import { RouterModule } from '@angular/router'; 

import { TruncateDescriptionPipe } from '../truncate-description.pipe/truncate-description.pipe'; 

 

@Component({ 

  selector: 'app-category', 

  standalone: true, 

  imports: [CommonModule,AdminNavBarComponent,UserNavComponent,RouterModule,TruncateDescriptionPipe], 

  templateUrl: './category.component.html', 

  styleUrl: './category.component.css' 

}) 

export class CategoryComponent implements OnInit { 

  categoryId!: number; 

  products: any[] = []; 

  isAdmin:boolean=false; 

  cartItems: any[] = []; 

  customerId: any = null; 

  cartId: any = null; 

  averageRatings: { [productId: number]: number } = {}; 

  filteredProducts:any[]=[] 

  constructor(private route: ActivatedRoute, private authService: AuthService,private router:Router) {} 

 

  ngOnInit(): void { 

    const role = localStorage.getItem('role'); 

    if(role=="ADMIN"){ 

      this.isAdmin = true; 

    } 

    else{ 

      this.isAdmin = false; 

    } 

    this.route.paramMap.subscribe(params => { 

      this.categoryId = +params.get('categoryId')!; 

      this.loadProductsByCategory(this.categoryId); 

    }); 

    this.loadProductsByCategory(this.categoryId); 

 

  } 

   

  onSearch(query: string) { 

    this.filteredProducts = this.products.filter(product => 

      product.productName.toLowerCase().includes(query.toLowerCase()) 

    ); 

  } 

 

  loadProductsByCategory(categoryId:number) { 

    this.authService.getProductsByCategory(categoryId).subscribe({ 

      next: (data: any) => { 

        this.products = data.productDtos; 

        this.filteredProducts = [...this.products]; 

        console.log(this.filteredProducts); 

 

        // ⭐ Load ratings for each product 

        this.filteredProducts.forEach((product: any) => { 

          this.loadAverageRating(product.productId); 

        }); 

         

      }, 

      error: (err) => console.error('Failed to fetch products', err), 

    }); 

 

    this.loadCart(); 

  } 

 

  loadCart(): void { 

    this.authService.getCustomerDetails().subscribe({ 

      next: (res) => { 

        this.customerId = res.user.customerID; 

        this.authService.getCartByCustomerId(this.customerId).subscribe({ 

          next: (res) => { 

            this.cartId = res.cartDto.cartId; 

            this.authService.getCartItems(this.cartId).subscribe({ 

              next: (itemsRes) => { 

                this.cartItems = itemsRes.cartItemsDtos; 

              }, 

              error: (err) => { 

                console.error('Error fetching cart items:', err); 

              } 

            }); 

          }, 

          error: (err) => { 

            console.error('Error fetching cart:', err); 

          } 

        }); 

      }, 

      error: (err) => { 

        console.error('Error fetching customer details:', err); 

      } 

    }); 

  } 

 

  isInCart(productId: number): boolean { 

    return this.cartItems?.some(item => item.productId === productId); 

  } 

 

  toggleCart(productId: number): void { 

    if (!this.cartId) { 

      console.warn('Cart ID is not yet available'); 

      return; 

    } 

 

    if (this.isInCart(productId)) { 

      this.authService.deleteCartItem(productId, this.cartId).subscribe({ 

        next: () => { 

          console.log('Removed from cart'); 

          this.loadCart(); 

        }, 

        error: (err) => { 

          console.error('Error removing from cart:', err); 

        } 

      }); 

    } else { 

      const cartItemDto = { 

        cartId: this.cartId, 

        productId: productId, 

        quantity: 1 

      }; 

 

      this.authService.addCartItem(cartItemDto).subscribe({ 

        next: () => { 

          console.log('Added to cart'); 

          this.loadCart(); 

        }, 

        error: (err) => { 

          console.error('Error adding to cart:', err); 

        } 

      }); 

    } 

  } 

  buyNow(item: any): void { 

    const selectedProduct = { 

      productId: item.productId, 

      productName: item.productName, 

      productDescription: item.productDescription, 

      productPrice: item.productPrice, 

      quantity: item.quantity, 

      productImage: item.productImage 

    }; 

    this.authService.selectedProducts = [selectedProduct]; 

    this.router.navigate(['/buy']); 

  } 

  resetProductList(): void { 

    this.filteredProducts = [...this.products]; 

  } 

  loadAverageRating(productId: number) { 

    this.authService.getReviewsByProduct(productId).subscribe({ 

      next: (response) => { 

        const reviews = response.reviewDtos; 

        if (reviews.length === 0) { 

          this.averageRatings[productId] = 0; 

          return; 

        } 

        const sum = reviews.reduce((acc: number, r: any) => acc + r.rating, 0); 

        const avg = sum / reviews.length; 

        this.averageRatings[productId] = +avg.toFixed(1); 

      }, 

      error: (err) => { 

        console.error("Error fetching reviews:", err); 

        this.averageRatings[productId] = 0; 

      } 

    }); 

  } 

} 

