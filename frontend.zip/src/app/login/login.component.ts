
import { Component } from '@angular/core'; 

import { FormBuilder, FormGroup, Validators,ReactiveFormsModule } from '@angular/forms'; 

import { AuthService } from '../services/auth.service'; 

import { Router, RouterModule } from '@angular/router'; 

import { CommonModule } from '@angular/common'; 

import { HttpClientModule } from '@angular/common/http';
 

@Component({ 

  selector: 'app-login', 

  standalone:true, 

  imports: [CommonModule,ReactiveFormsModule,RouterModule,HttpClientModule], 

  templateUrl: './login.component.html', 

  styleUrl: './login.component.scss' 

}) 

export class LoginComponent { 

  loginForm:FormGroup; 

  errorMessage : "" | string; 

  constructor( 

    private fb:FormBuilder, 

    private authService : AuthService, 

    private router : Router 

  ){ 

    this.loginForm = this.fb.group({ 

      email : ['',Validators.required], 

      password : ['',Validators.required] 

    }); 

    this.errorMessage = ""; 

  } 

  onLogin(){ 

    if(this.loginForm.invalid) return; 

 

    this.authService.login(this.loginForm.value).subscribe({ 

      next: (res) => { 

        if (res.token) { 

          localStorage.setItem('token', res.token); 

          localStorage.setItem('role', res.role); 

           

          if (res.role === "ADMIN") { 

            this.authService.setLoginType('admin'); 

            this.router.navigate(['/admin-home']); 

          } else { 

            this.authService.setLoginType('user'); 

            this.router.navigate(['/user-home']); 

          } 

        } else { 

          this.errorMessage = 'Invalid credentials'; 

        } 

      }, 

      error: () => { 

        this.errorMessage = 'Invalid credentials'; 

      }, 

    }); 

     

  } 

  register() { 

     this.router.navigate(['/register']); 

    } 

} 
