import { HttpInterceptorFn } from '@angular/common/http'; 

import { inject, PLATFORM_ID } from '@angular/core'; 

import { AuthService } from '../services/auth.service'; 

import { isPlatformBrowser } from '@angular/common'; 

 

export const JwtInterceptor: HttpInterceptorFn = (req, next) => { 

  const authService = inject(AuthService); 

  const platformId = inject(PLATFORM_ID); 

  if (isPlatformBrowser(platformId)) { 

    const jwtToken = authService.getToken(); 

 

    if (jwtToken) { 

      const cloned = req.clone({ 

        setHeaders: { 

          Authorization: `Bearer ${jwtToken}` 

        } 

      }); 

      return next(cloned); 

    } 

  } 

 

  return next(req); 

}; 

 
