
import { Component, OnInit } from '@angular/core'; 

import { AuthService } from '../services/auth.service'; 

import { Router } from '@angular/router'; 

import { CommonModule } from '@angular/common'; 

import { AdminNavBarComponent } from "../admin-nav-bar/admin-nav-bar.component"; 

import { RouterModule } from '@angular/router'; 

import { UserNavComponent } from '../user-nav/user-nav.component'; 

import { FormsModule } from '@angular/forms'; 

import { Observable,of,catchError } from 'rxjs'; 

 

interface PaymentDTO { 

  paymentId: number; 

  orderId: number; 

  paymentMethod: string; 

  paymentStatus: string; 

  paymentDate: string; 

} 

 

interface OrderItemDTO { 

  orderDetailId: number; 

  orderId: number; 

  productId: number; 

  quantity: number; 

  price: number; 

} 

 

interface ProductDTO { 

  productId: number; 

  productName: string; 

  productDescription: string; 

  productPrice: number; 

  availableQuantity: number; 

  productImage: string; 

} 

 

@Component({ 

  selector: 'app-payments', 

  standalone: true, 

  imports: [CommonModule, AdminNavBarComponent,RouterModule, UserNavComponent, FormsModule], 

  templateUrl: './payments.component.html', 

  styleUrls: ['./payments.component.css'] 

}) 

export class PaymentsComponent implements OnInit { 

  customerId: any; 

  paymentDtos: PaymentDTO[] = []; 

  orderItemsMap: { [orderId: number]: OrderItemDTO[] } = {}; 

  productDetails: { [key: number]: ProductDTO } = {}; 

  isAdmin: boolean = false; 

  searchTerm: string = ''; 

 

  constructor(private router: Router, private authService: AuthService) {} 

 

  ngOnInit(): void { 

    const role = localStorage.getItem('role'); 

    this.isAdmin = role === 'ADMIN'; 

    this.getPayments(); 

  } 

 

  getPayments(): void { 

    this.authService.getCustomerDetails().subscribe({ 

      next: (res) => { 

        this.customerId = res.user.customerID; 

        console.log("customer ID : "+this.customerId) 

        this.fetchPayments(); 

      }, 

      error: (err) => { 

        console.error('Error fetching customer details', err); 

      } 

    }); 

  } 

 

  fetchPayments(): void { 

    if (this.customerId) { 

      this.authService.getPaymentsByCustomer(this.customerId).subscribe({ 

        next: (res) => { 

          this.paymentDtos = res.paymentDtos; 

          console.log("paymenets : "+this.paymentDtos[0].orderId) 

          this.paymentDtos.forEach(payment => { 

            this.fetchOrderItems(payment.orderId); 

            this.getTotalAmount(payment.orderId); 

          });           

        }, 

        error: (err) => { 

          console.error('Error fetching payments', err); 

        } 

      }); 

    } else { 

      console.error('Customer ID is not available'); 

    } 

     

  } 

 

  fetchOrderItems(orderId: number): void { 

    this.authService.getOrderItemsByOrderId(orderId).subscribe({ 

      next: (res) => { 

        if (res.orderItemDtos) { 

          console.log(res.orderItemDtos[0].orderDetailId); 

          this.orderItemsMap[orderId] = res.orderItemDtos; 

          for (const orderId in this.orderItemsMap) { 

            const items = this.orderItemsMap[orderId]; 

            console.log(`Order ID: ${orderId}`, items); 

          }           

          for (const orderId in this.orderItemsMap) { 

            const orderItems = this.orderItemsMap[orderId]; 

            orderItems.forEach(item => { 

              const productId = item.productId; 

              this.fetchProductDetails(productId); 

            }); 

          }           

        } 

      }, 

      error: (err) => { 

        console.error('Error fetching order items for orderId:', orderId, err); 

      } 

    }); 

  } 

 

  fetchProductDetails(productId: number): void { 

    this.authService.getProductById(productId).subscribe({ 

      next: (res) => { 

        if (res.productDto) { 

          this.productDetails[productId] = res.productDto; 

        } 

      }, 

      error: (err) => { 

        console.error('Error fetching product details for productId:', productId, err); 

      } 

    }); 

  } 

  totalAmounts: { [orderId: number]: number } = {}; 

  getTotalAmount(orderId: number): void { 

    this.authService.getOrderAmountById(orderId).subscribe({ 

      next: (amount: number) => { 

        this.totalAmounts[orderId] = amount; 

        console.log(`Order ID: ${orderId}, Amount: ₹${amount}`); 

      }, 

      error: (err) => { 

        console.error('Failed to fetch amount:', err); 

      } 

    }); 

  } 

   

 

  isLast(arr: any[], item: any): boolean { 

    return arr.indexOf(item) === arr.length - 1; 

  } 

 

  // Handle search term change 

  onSearch(searchTerm: string): void { 

    this.searchTerm = searchTerm; 

  } 

 

  get filteredPaymentDtos() { 

    return this.paymentDtos.filter(payment => { 

      const items = this.orderItemsMap[payment.orderId] || []; 

      return items.some(item => { 

        const product = this.productDetails[item.productId]; 

        return product && 

          (product.productName?.toLowerCase().includes(this.searchTerm.toLowerCase()) || 

           product.productDescription?.toLowerCase().includes(this.searchTerm.toLowerCase())); 

      }); 

    }); 

  } 

   

  filterItems(items: any[]) { 

    return items.filter(item => { 

      const product = this.productDetails[item.productId]; 

      return product && 

        (product.productName?.toLowerCase().includes(this.searchTerm.toLowerCase()) || 

         product.productDescription?.toLowerCase().includes(this.searchTerm.toLowerCase())); 

    }); 

  } 

   

} 
