
import { Component, OnInit } from '@angular/core'; 

import { AuthService } from '../services/auth.service'; 

import { Router } from '@angular/router'; 

import { CommonModule } from '@angular/common'; 

import { AdminNavBarComponent } from "../admin-nav-bar/admin-nav-bar.component"; 

import { RouterModule } from '@angular/router'; 

import { UserNavComponent } from '../user-nav/user-nav.component'; 

import { FormsModule } from '@angular/forms'; 

declare var bootstrap: any; 

 

interface OrderDTO { 

  orderId: number; 

  userId: number; 

  orderStatus: string; 

  totalAmount: number; 

  createdAt: string; 

} 

 

interface OrderItemDTO { 

  orderDetailId: number; 

  orderId: number; 

  productId: number; 

  quantity: number; 

  price: number; 

} 

 

interface ProductDTO { 

  productId: number; 

  productName: string; 

  productDescription: string; 

  productPrice: number; 

  availableQuantity: number; 

  productImage: string; 

} 

 

interface ShippingAddressDTO { 

  shippingId: number; 

  orderId: number; 

  name: string; 

  phnNo: string; 

  hno: string; 

  street: string; 

  city: string; 

  state: string; 

  pincode: string; 

  shippingDate: string; 

} 

 

@Component({ 

  selector: 'app-orders', 

  standalone: true, 

  imports: [CommonModule, AdminNavBarComponent, RouterModule, UserNavComponent, FormsModule], 

  templateUrl: './orders.component.html', 

  styleUrls: ['./orders.component.css'] 

}) 

export class OrdersComponent implements OnInit { 

  customerId: any; 

  orderDtos: OrderDTO[] = []; 

  orderHistory: OrderDTO[] = []; 

  orderItemsMap: { [orderId: number]: OrderItemDTO[] } = {}; 

  shippingAddressMap: { [orderId: number]: ShippingAddressDTO } = {}; 

  activeOrders: OrderDTO[] = []; 

  productDetailsMap: { [productId: number]: ProductDTO } = {}; 

  cancelledOrders: OrderDTO[] = []; 

  selectedOrderId: number | null = null; 

  isAdmin: boolean = false; 

  searchQuery: string = ''; 

 

  constructor(private router: Router, private authService: AuthService) {} 

 

  ngOnInit(): void { 

    const role = localStorage.getItem('role'); 

    this.isAdmin = role === 'ADMIN'; 

    this.getOrders(); 

  } 

 

  getOrders(): void { 

    this.authService.getCustomerDetails().subscribe({ 

      next: (res) => { 

        this.customerId = res.user.customerID; 

        this.fetchOrders(); 

      }, 

      error: (err) => console.error('Error fetching customer details', err) 

    }); 

  } 

 

  fetchOrders(): void { 

    if (!this.customerId) return; 

 

    this.authService.getOrdersByCustomerId(this.customerId).subscribe({ 

      next: (res) => { 

        this.orderDtos = res.orderDtos; 

        this.orderHistory = []; 

        this.activeOrders = []; 

        this.cancelledOrders = []; 

 

        this.orderDtos.forEach(order => { 

          this.fetchOrderItems(order.orderId); 

          this.fetchShippingAddress(order.orderId); 

        }); 

      }, 

      error: (err) => console.error('Error fetching orders', err) 

    }); 

  } 

 

  fetchOrderItems(orderId: number): void { 

    this.authService.getOrderItemsByOrderId(orderId).subscribe({ 

      next: (res:any) => { 

         

        this.orderItemsMap[orderId] = res.orderItemDtos || []; 

        // Explicitly typing `item` as `OrderItemDTO` 

        res.orderItemDtos?.forEach((item: OrderItemDTO) => { 

          this.fetchProductDetails(item.productId); 

        }); 

      }, 

      error: (err) => console.error(`Error fetching items for order ${orderId}`, err) 

    }); 

  } 

   

   

 

  fetchProductDetails(productId: number): void { 

    if (this.productDetailsMap[productId]) return; 

    this.authService.getProductById(productId).subscribe({ 

      next: (res) => { 

        if (res.productDto!=null) { 

          this.productDetailsMap[productId] = res.productDto; 

        } 

      }, 

      error: (err) => console.error(`Error fetching product ${productId}`, err) 

    }); 

  } 

 

  fetchShippingAddress(orderId: number): void { 

    this.authService.getShippingAddressByOrderId(orderId).subscribe({ 

      next: (res) => { 

        const shipping = res.shippingAddressDto; 

        if (!shipping) return; 

 

        this.shippingAddressMap[orderId] = shipping; 

 

        const shippingDate = new Date(shipping.shippingDate); 

        const today = new Date(); 

        today.setHours(0, 0, 0, 0); 

 

        const order = this.orderDtos.find(o => o.orderId === orderId); 

        if (!order) return; 

 

        if (order.orderStatus === 'Canceled' || order.orderStatus === 'canceled') { 

          this.cancelledOrders.push(order); 

        } else if (shippingDate >= today) { 

          this.activeOrders.push(order); 

        } else { 

          this.orderHistory.push(order); 

        } 

      }, 

      error: (err) => console.error(`Error fetching shipping for order ${orderId}`, err) 

    }); 

  } 

 

  confirmCancel(orderId: number): void { 

    this.selectedOrderId = orderId; 

    const modalEl = document.getElementById('cancelModal'); 

    if (modalEl) new bootstrap.Modal(modalEl).show(); 

  } 

 

  cancelOrderConfirmed(): void { 

    const orderId = this.selectedOrderId; 

    if (orderId === null) return; 

 

    this.authService.updateOrderStatus(orderId, 'Canceled').subscribe({ 

      next: () => { 

        this.authService.cancelShipping(orderId).subscribe({ 

          next: (res) => { 

            const updatedShipping = res.shippingAddressDto; 

            if (updatedShipping) { 

              this.shippingAddressMap[orderId] = updatedShipping; 

            } 

          }, 

          error: (err) => console.error('Error canceling shipping:', err) 

        }); 

 

        this.authService.getPaymentByOrderId(orderId).subscribe({ 

          next: (res) => { 

            const payment = res.paymentDtos?.[0]; 

            if (!payment) return this.fetchOrders(); 

 

            const status = payment.paymentMethod === 'COD' ? 'Canceled' : 'Canceled and Refunded'; 

            this.authService.updatePaymentStatus(payment.paymentId, status).subscribe({ 

              next: () => this.fetchOrders(), 

              error: (err) => { 

                console.error('Error updating payment:', err); 

                alert('Order canceled but failed to update payment.'); 

              } 

            }); 

          }, 

          error: (err) => { 

            console.error('Error fetching payment:', err); 

            alert('Order canceled but failed to fetch payment.'); 

            this.fetchOrders(); 

          } 

        }); 

 

        this.incrementProductQuantitiesInCanceledOrder(orderId); 

      }, 

      error: (err) => { 

        console.error('Cancel failed:', err); 

        alert('Failed to cancel. Try again.'); 

      } 

    }); 

 

    const modalEl = document.getElementById('cancelModal'); 

    if (modalEl) bootstrap.Modal.getInstance(modalEl)?.hide(); 

 

    this.selectedOrderId = null; 

  } 

 

  onSearch(query: string): void { 

    this.searchQuery = query.toLowerCase(); 

 

    if (!this.searchQuery) { 

      this.fetchOrders(); 

    } else { 

      this.activeOrders = this.filterOrders(this.activeOrders, this.searchQuery); 

      this.orderHistory = this.filterOrders(this.orderHistory, this.searchQuery); 

      this.cancelledOrders = this.filterOrders(this.cancelledOrders, this.searchQuery); 

    } 

  } 

 

  filterOrders(orders: OrderDTO[], query: string): OrderDTO[] { 

    return orders.filter(order => 

      order.orderId.toString().includes(query) || 

      this.orderItemsMap[order.orderId]?.some(item => 

        this.productDetailsMap[item.productId]?.productName.toLowerCase().includes(query) 

      ) 

    ); 

  } 

 

  incrementProductQuantitiesInCanceledOrder(orderId: number): void { 

    const items = this.orderItemsMap[orderId]; 

    if (!items) return; 

 

    items.forEach(item => { 

      this.authService.incrementProductQuantity(item.productId, item.quantity).subscribe({ 

        next: () => console.log(`Restored qty for product ${item.productId}`), 

        error: (err) => console.error(`Failed to restore qty for ${item.productId}`, err) 

      }); 

    }); 

  } 

 

  hasValidProducts(orderId: number): boolean { 

    return this.orderItemsMap[orderId]?.some(item => this.productDetailsMap[item.productId]); 

  } 

} 
