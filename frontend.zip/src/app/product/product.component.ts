
import { Component, OnInit } from '@angular/core'; 

import { CommonModule } from '@angular/common'; 

import { ActivatedRoute, Router } from '@angular/router'; 

import { AuthService } from '../services/auth.service'; 

import { RouterModule } from '@angular/router'; 

import { AdminNavBarComponent } from "../admin-nav-bar/admin-nav-bar.component"; 

import { FormsModule } from '@angular/forms'; 

import { UserNavComponent } from '../user-nav/user-nav.component'; 

 

@Component({ 

  selector: 'app-product', 

  standalone: true, 

  imports: [CommonModule, RouterModule, AdminNavBarComponent,FormsModule,UserNavComponent], 

  templateUrl: './product.component.html', 

  styleUrls: ['./product.component.css'] 

}) 

export class ProductComponent implements OnInit { 

  product: any = null; 

  cartItems: any[] = []; 

  customerId: any = null; 

  cartId: any = null; 

  isAdmin:boolean = false; 

   

  reviewTextError: string = '';   

  reviewRatingError: string = ''; 

 

  constructor( 

    private route: ActivatedRoute, 

    private authService: AuthService, 

    private router : Router 

  ) { 

     

  } 

 

  ngOnInit(): void { 

    const role = localStorage.getItem('role'); 

    if(role=="ADMIN"){ 

      this.isAdmin = true; 

    } 

    else{ 

      this.isAdmin = false; 

    } 

    const productId = +this.route.snapshot.paramMap.get('id')!; 

    if (productId) { 

      this.authService.getProductById(productId).subscribe({ 

        next: (data:any) => { 

          this.product = data?.productDto; 

          this.loadCart(); // Load cart after product is available 

          this.loadReviews(); 

        }, 

        error: (err) => { 

          console.error('Error fetching product:', err); 

        } 

      }); 

    } 

  } 

 

  loadCart(): void { 

    this.authService.getCustomerDetails().subscribe({ 

      next: (res) => { 

        this.customerId = res.user.customerID; 

        this.authService.getCartByCustomerId(this.customerId).subscribe({ 

          next: (res) => { 

            this.cartId = res.cartDto.cartId; 

            this.authService.getCartItems(this.cartId).subscribe({ 

              next: (itemsRes) => { 

                this.cartItems = itemsRes.cartItemsDtos; 

              }, 

              error: (err) => { 

                console.error('Error fetching cart items:', err); 

              } 

            }); 

          }, 

          error: (err) => { 

            console.error('Error fetching cart:', err); 

          } 

        }); 

      }, 

      error: (err) => { 

        console.error('Error fetching customer details:', err); 

      } 

    }); 

  } 

 

  isInCart(productId: number): boolean { 

    return this.cartItems?.some(item => item.productId === productId); 

  } 

 

  toggleCart(productId: number): void { 

    if (!this.cartId) { 

      console.warn('Cart ID is not yet available'); 

      return; 

    } 

 

    if (this.isInCart(productId)) { 

      this.authService.deleteCartItem(productId, this.cartId).subscribe({ 

        next: () => { 

          console.log('Removed from cart'); 

          this.loadCart(); 

        }, 

        error: (err) => { 

          console.error('Error removing from cart:', err); 

        } 

      }); 

    } else { 

      const cartItemDto = { 

        cartId: this.cartId, 

        productId: productId, 

        quantity: 1 

      }; 

 

      this.authService.addCartItem(cartItemDto).subscribe({ 

        next: () => { 

          console.log('Added to cart'); 

          this.loadCart(); 

        }, 

        error: (err) => { 

          console.error('Error adding to cart:', err); 

        } 

      }); 

    } 

  } 

 

  buyNow(item:any):void{ 

    const selectedProduct = { 

      productId: item.productId, 

      productName: item.productName, 

      productDescription: item.productDescription, 

      productPrice: item.productPrice, 

      quantity: item.quantity, 

      productImage: item.productImage 

    } 

  this.authService.selectedProducts = [selectedProduct]; 

    this.router.navigate(['/buy']); 

  } 

 

  reviewText: string = ''; 

reviewRating: number = 0; 

reviews: any[] = []; 

 

 

submitReview(): void { 

  // Clear previous errors 

  this.reviewTextError = ''; 

  this.reviewRatingError = ''; 

 

  // Validate inputs 

  if (!this.reviewText) { 

    this.reviewTextError = 'Review text is required'; 

  } 

 

  if (!this.reviewRating) { 

    this.reviewRatingError = 'Rating is required'; 

  } 

 

  // If there are errors, do not proceed 

  if (this.reviewTextError || this.reviewRatingError) { 

    return; 

  } 

 

  this.authService.getCustomerDetails().subscribe({ 

    next: (res) => { 

      const review = { 

        productId: this.product.productId, 

        customerId: res.user.customerID, 

        description: this.reviewText, 

        rating: this.reviewRating 

      }; 

 

      console.log(review); 

 

      this.authService.addReview(review).subscribe({ 

        next: () => { 

          console.log("review added"); 

          this.reviewText = ''; 

          this.reviewRating = 0; 

          this.loadReviews(); 

        }, 

        error: (err) => { 

          console.error('Error adding review:', err); 

        } 

      }); 

    } 

  }); 

} 

 

loadReviews(): void { 

  if (this.product?.productId) { 

    this.authService.getReviewsByProduct(this.product.productId).subscribe({ 

      next: (res:any) => { 

        console.log(res); 

        this.reviews = res.reviewDtos; 

      }, 

      error: (err) => { 

        console.error('Error loading reviews:', err); 

      } 

    }); 

  } 

} 

} 
