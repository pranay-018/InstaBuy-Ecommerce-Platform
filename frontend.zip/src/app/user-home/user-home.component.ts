
import { Component } from '@angular/core'; 

import { AuthService } from '../services/auth.service'; 

import { Router } from '@angular/router'; 

import { CommonModule } from '@angular/common'; 

import { UserNavComponent } from '../user-nav/user-nav.component'; 

import { RouterModule } from '@angular/router'; 

import { TruncateDescriptionPipe } from '../truncate-description.pipe/truncate-description.pipe'; 

import { AdminNavBarComponent } from '../admin-nav-bar/admin-nav-bar.component'; 

@Component({ 

  selector: 'app-userhome', 

  standalone: true, 
  imports: [CommonModule,AdminNavBarComponent, UserNavComponent, RouterModule, TruncateDescriptionPipe], 

  templateUrl: './user-home.component.html', 

  styleUrl: './user-home.component.css', 

}) 

export class UserhomeComponent { 

  products: any[] = []; 

  filteredProducts: any[] = []; 

  cartItems: any[] = []; 

  customerId: any = null; 

  cartId: any = null; 

  averageRatings: { [productId: number]: number } = {}; 

  isAdmin:boolean=false; 

 

  constructor(private authService: AuthService, private router: Router) { } 

 

  ngOnInit(): void { 

    const role = localStorage.getItem('role'); 

    if(role=="ADMIN"){ 

      this.isAdmin = true; 

    } 

    else{ 

      this.isAdmin = false; 

    } 

    this.authService.getProducts().subscribe({ 

      next: (data: any) => { 

        this.products = data.productDtos; 

        this.filteredProducts = [...this.products]; 

        console.log(this.filteredProducts); 

        this.filteredProducts.forEach((product: any) => { 

          this.loadAverageRating(product.productId); 

        }); 

      }, 

      error: (err) => console.error('Failed to fetch products', err), 

    }); 

 

    this.loadCart(); // Load the cart when page opens 

  } 

 

  onSearch(query: string) { 

    this.filteredProducts = this.products.filter(product => 

      product.productName.toLowerCase().includes(query.toLowerCase()) 

    ); 

  } 

  onCategorySelected(categoryId: number): void { 

    const filtered = this.products.filter( 

      (product: any) => Number(product.categoryId) === Number(categoryId) 

    ); 

   

    this.filteredProducts = filtered.length > 0 ? filtered : [...this.products]; 

  } 

   

  // --- CART METHODS --- 

 

  loadCart(): void { 

    this.authService.getCustomerDetails().subscribe({ 

      next: (res) => { 

        this.customerId = res.user.customerID; 

        this.authService.getCartByCustomerId(this.customerId).subscribe({ 

          next: (res) => { 

            this.cartId = res.cartDto.cartId; 

            this.authService.getCartItems(this.cartId).subscribe({ 

              next: (itemsRes) => { 

                this.cartItems = itemsRes.cartItemsDtos; 

              }, 

              error: (err) => { 

                console.error('Error fetching cart items:', err); 

              } 

            }); 

          }, 

          error: (err) => { 

            console.error('Error fetching cart:', err); 

          } 

        }); 

      }, 

      error: (err) => { 

        console.error('Error fetching customer details:', err); 

      } 

    }); 

  } 

 

  isInCart(productId: number): boolean { 

    return this.cartItems?.some(item => item.productId === productId); 

  } 

 

  toggleCart(productId: number): void { 

    if (!this.cartId) { 

      console.warn('Cart ID is not yet available'); 

      return; 

    } 

 

    if (this.isInCart(productId)) { 

      this.authService.deleteCartItem(productId, this.cartId).subscribe({ 

        next: () => { 

          console.log('Removed from cart'); 

          this.loadCart(); 

        }, 

        error: (err) => { 

          console.error('Error removing from cart:', err); 

        } 

      }); 

    } else { 

      const cartItemDto = { 

        cartId: this.cartId, 

        productId: productId, 

        quantity: 1 

      }; 

 

      this.authService.addCartItem(cartItemDto).subscribe({ 

        next: () => { 

          console.log('Added to cart'); 

          this.loadCart(); 

        }, 

        error: (err) => { 

          console.error('Error adding to cart:', err); 

        } 

      }); 

    } 

  } 

  loadAverageRating(productId: number) { 

    this.authService.getReviewsByProduct(productId).subscribe({ 

      next: (response) => { 

        const reviews = response.reviewDtos; 

        if (reviews.length === 0) { 

          this.averageRatings[productId] = 0; 

          return; 

        } 

        const sum = reviews.reduce((acc: number, r: any) => acc + r.rating, 0); 

        const avg = sum / reviews.length; 

        this.averageRatings[productId] = +avg.toFixed(1); 

      }, 

      error: (err) => { 

        console.error("Error fetching reviews:", err); 

        this.averageRatings[productId] = 0; 

      } 

    }); 

  } 

 

  buyNow(item: any): void { 

    const selectedProduct = { 

      productId: item.productId, 

      productName: item.productName, 

      productDescription: item.productDescription, 

      productPrice: item.productPrice, 

      quantity: item.quantity, 

      productImage: item.productImage 

    }; 

    this.authService.selectedProducts = [selectedProduct]; 

    this.router.navigate(['/buy']); 

  } 

  resetProductList(): void { 

    this.filteredProducts = [...this.products]; 

  } 

} 
