
import { Routes } from '@angular/router'; 

import { LoginComponent } from './login/login.component'; 

import { RegisterComponent } from './register/register.component'; 

import { AddProductComponent } from './add-product/add-product.component'; 

import { AddCategoryComponent } from './add-category/add-category.component'; 

import { ProductListComponent } from './product-list/product-list.component'; 

import { CategoryListComponent } from './category-list/category-list.component'; 

import { AdminHomeComponent } from './admin-home/admin-home.component'; 

import { ProfileComponent } from './profile/profile.component'; 

import { EditProfileComponent } from './edit-profile/edit-profile.component'; 

import { AdminProfileComponent } from './admin-profile/admin-profile.component'; 

import { MakeAdminComponent } from './make-admin/make-admin.component'; 

import { AdminDashboardComponent } from './admin-dashboard/admin-dashboard.component'; 

import { CartComponent } from './cart/cart.component'; 

import { ProductComponent } from './product/product.component'; 

import { BuyComponent } from './buy/buy.component'; 

import { PaymentsComponent } from './payments/payments.component'; 

import { OrdersComponent } from './orders/orders.component'; 

import { UserhomeComponent } from './user-home/user-home.component'; 

import { CategoryComponent } from './category/category.component'; 

import { RoleGuard } from './auth.guard'; 

import { PageNotFoundComponent } from './page-not-found/page-not-found.component'; 

import { AllOrdersComponent } from './all-orders/all-orders.component'; 

import { AllTransactionComponent } from './all-transaction/all-transaction.component'; 

import { HttpClientModule } from '@angular/common/http';
 

export const routes: Routes = [ 

    { path: '', redirectTo: 'login', pathMatch: 'full' }, 

    { path: 'login', component: LoginComponent }, 

    { path: 'register', component: RegisterComponent }, 

 

    // Shared routes (ADMIN + USER) 

    { path: 'edit-profile', component: EditProfileComponent, canActivate: [RoleGuard], data: { roles: ['USER', 'ADMIN'] } }, 

    { path: 'cart', component: CartComponent, canActivate: [RoleGuard], data: { roles: ['USER', 'ADMIN'] } }, 

    { path: 'product/:id', component: ProductComponent, canActivate: [RoleGuard], data: { roles: ['USER', 'ADMIN'] } }, 

    { path: 'buy', component: BuyComponent, canActivate: [RoleGuard], data: { roles: ['USER', 'ADMIN'] } }, 

    { path: 'payments', component: PaymentsComponent, canActivate: [RoleGuard], data: { roles: ['USER', 'ADMIN'] } }, 

    { path: 'orders', component: OrdersComponent, canActivate: [RoleGuard], data: { roles: ['USER', 'ADMIN'] } }, 

    { path: 'category/:categoryId', component: CategoryComponent, canActivate: [RoleGuard], data: { roles: ['USER', 'ADMIN'] } }, 

 

    // User-only routes 

    { path: 'user-home', component: UserhomeComponent, canActivate: [RoleGuard], data: { roles: ['USER'] } }, 

    { path: 'profile', component: ProfileComponent, canActivate: [RoleGuard], data: { roles: ['USER'] } }, 

 

    // Admin-only routes 

    { 

        path: 'admin-home', 

        component: AdminHomeComponent, 

        canActivate: [RoleGuard], 

        data: { roles: ['ADMIN'] } 

    }, 

    { path: 'add-product', component: AddProductComponent, canActivate: [RoleGuard], data: { roles: ['ADMIN'] } }, 

    { path: 'add-category', component: AddCategoryComponent, canActivate: [RoleGuard], data: { roles: ['ADMIN'] } }, 

    { path: 'product-list', component: ProductListComponent, canActivate: [RoleGuard], data: { roles: ['ADMIN'] } }, 

    { path: 'category-list', component: CategoryListComponent, canActivate: [RoleGuard], data: { roles: ['ADMIN'] } }, 

    { path: 'admin-profile', component: AdminProfileComponent, canActivate: [RoleGuard], data: { roles: ['ADMIN'] } }, 

    { path: 'make-admin', component: MakeAdminComponent, canActivate: [RoleGuard], data: { roles: ['ADMIN'] } }, 

    { path: 'admin-dash', component: AdminDashboardComponent, canActivate: [RoleGuard], data: { roles: ['ADMIN'] } }, 

    {path:'all-orders',component:AllOrdersComponent,canActivate:[RoleGuard],data:{roles:['ADMIN']}}, 

    {path:'all-transaction',component:AllTransactionComponent,canActivate:[RoleGuard],data:{roles:['ADMIN']}}, 

    // Fallback 

    { path: 'page-not-found', component: PageNotFoundComponent }, 

    { path: '**', redirectTo: 'page-not-found' } 

]; 

