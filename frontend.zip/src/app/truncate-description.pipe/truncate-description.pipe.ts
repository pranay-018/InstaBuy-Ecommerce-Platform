
import { Pipe, PipeTransform } from '@angular/core'; 

 

@Pipe({ 

  name: 'truncateDescription', // This is the name you will use in the template 
  standalone: true

}) 

export class TruncateDescriptionPipe implements PipeTransform { 

  transform(value: string, maxLength: number = 100): string { 

    if (!value) return value; // If no value is provided, return as-is 

    return value.length > maxLength ? value.substring(0, maxLength) + '...' : value; 

  } 

} 