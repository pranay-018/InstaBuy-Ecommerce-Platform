import { CommonModule } from '@angular/common'; 

import { Component, EventEmitter, OnInit, Output } from '@angular/core'; 

import { FormsModule } from '@angular/forms'; 

import { Router } from '@angular/router'; 

import { AuthService } from '../services/auth.service'; 

 

@Component({ 

  selector: 'app-admin-nav-bar', 

  standalone: true, 

  imports: [CommonModule, FormsModule], 

  templateUrl: './admin-nav-bar.component.html', 

  styleUrl: './admin-nav-bar.component.css' 

}) 

export class AdminNavBarComponent  { 

  searchQuery: string = ''; 

  firstName: string = ''; 

  categories: any[] = []; 

  showCategoriesDropdown = false; 

 

  showProfileDropdown = false; 

   products :any = [] ; 

    @Output() searchEvent = new EventEmitter<string>(); 

    @Output() categorySelected = new EventEmitter<number>(); 

    @Output() resetProducts = new EventEmitter<void>(); 

  constructor(private router: Router, private authService: AuthService) {} 

 

  ngOnInit(): void { 

    this.authService.getFirstName().subscribe( 

      (response: { user: { firstName: string; }; }) => { 

        if (response && response.user && response.user.firstName) { 

          this.firstName = response.user.firstName; 

        } else { 

          console.error('Invalid response structure:', response); 

          this.firstName = 'Error loading name'; 

        } 

      }, 

      (error: any) => { 

        console.error('Error fetching first name:', error); 

        this.firstName = 'Error loading name'; 

      } 

    ); 

  } 

  onSearchChange() { 

        this.searchEvent.emit(this.searchQuery); 

      } 

    selectCategory(categoryId: number) { 

      this.hideCategoriesDropdown(); 

      this.router.navigate(['/category', categoryId]);  

    } 

 

  // Categories Dropdown 

  onCategoriesHover() { 

    this.showCategoriesDropdown = true; 

 

    if (this.categories.length === 0) { 

      this.authService.getCategories().subscribe( 

        (response:any) => { 

          this.categories = response.categoryDtos; 

        }, 

        (error) => { 

          console.error('Failed to fetch categories:', error); 

        } 

      ); 

    } 

  } 

 

  hideCategoriesDropdown() { 

    this.showCategoriesDropdown = false; 

  } 

 

  // Profile Dropdown 

  onProfileHover() { 

    this.showProfileDropdown = true; 

  } 

 

  hideProfileDropdown() { 

    this.showProfileDropdown = false; 

  } 

 

  // Navigation methods 

  navigateToHome() { 

    this.router.navigate(['/admin-home']); 

  } 

  goToCart() { 

    this.router.navigate(['/cart']); 

  } 

 

  goToCategories() { 

    this.router.navigate(['/category-list']); 

  } 

 

  goToProfile() { 

    this.router.navigate(['/admin-profile']); 

  } 

 

  goToDashboard() { 

    this.router.navigate(['/admin-dash']); 

  } 

 

  goToEditProfile() { 

    this.router.navigate(['/edit-profile']); 

  } 

 

  goToMyOrders() { 

    this.router.navigate(['/orders']); 

  } 

 

  goToMyTransactions() { 

    this.router.navigate(['/payments']); 

  } 

 

  goToAddProduct() { 

    this.router.navigate(['/add-product']); 

  } 

 

  goToAddCategory() { 

    this.router.navigate(['/add-category']); 

  } 

 

  goToListProducts() { 

    this.router.navigate(['/product-list']); 

  } 

 

  goToListCategories() { 

    this.router.navigate(['category-list']); 

  } 

  goToHome(){ 

    this.router.navigate(['/admin-home']); 

  } 

  goToMakeAdmin(){ 

    this.router.navigate(['/make-admin']); 

  } 

  logout() { 

    this.authService.logout(); 

    this.router.navigate(['/login']); 

  } 

  goToAllOrders(){ 

    this.router.navigate(['/all-orders']); 

 

  } 

  goToAllTransactions(){ 

    this.router.navigate(['/all-transaction']); 

  } 

} 

