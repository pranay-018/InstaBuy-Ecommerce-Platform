
import { Component, OnInit } from '@angular/core'; 

import { AuthService } from '../services/auth.service'; 

import { AdminNavBarComponent } from "../admin-nav-bar/admin-nav-bar.component"; 

import { CommonModule } from '@angular/common'; 

import { FormsModule } from '@angular/forms'; 

 

@Component({ 

  selector: 'app-make-admin', 

  standalone:true, 

  templateUrl: './make-admin.component.html', 

  styleUrls: ['./make-admin.component.css'], 

  imports: [AdminNavBarComponent,CommonModule,FormsModule] 

}) 

export class MakeAdminComponent implements OnInit { 

  customers: any[] = []; 

  errorMessage: string = ''; 

  successMessage: string = ''; 

  loggedInAdminEmail: string = ''; 

  toastMessage: string = ''; 

toastType: 'success' | 'error' = 'success'; 

showToast: boolean = false; 

searchText: string = ''; 

sortColumn: string = ''; 

sortDirection: 'asc' | 'desc' = 'asc'; 

 

  constructor(private authService: AuthService) {} 

 

  ngOnInit(): void { 

    this.loggedInAdminEmail = this.authService.getLoggedInUserEmail(); // Add this line 

    this.loadAllCustomers(); 

    this.loadAllCustomers(); 

  } 

  loadAllCustomers(): void { 

    this.authService.getAllCustomers().subscribe({ 

      next: (res) => { 

        this.customers = res.customersdtos || []; 

        console.log(this.customers); 

      }, 

      error: () => { 

        this.errorMessage = 'Failed to fetch customer details.'; 

      } 

    }); 

  } 

  toggleRole(customer: any): void { 

    const newRole = customer.role === 'USER' ? 'ADMIN' : 'USER'; 

    this.authService.updateUserRole(customer.customerID, newRole).subscribe({ 

      next: () => { 

        customer.role = newRole; 

        this.successMessage = `Successfully updated role to ${newRole}`; 

      }, 

      error: () => { 

        this.errorMessage = 'Failed to update role.'; 

      } 

    }); 

  } 

  getLoggedInUserEmail(): string { 

    const user = JSON.parse(localStorage.getItem('user') || '{}'); 

    return user.email || ''; 

  } 

 

 

 

showSuccess(message: string) { 

  this.toastMessage = message; 

  this.toastType = 'success'; 

  this.showToast = true; 

  setTimeout(() => this.showToast = false, 3000); 

} 

 

showError(message: string) { 

  this.toastMessage = message; 

  this.toastType = 'error'; 

  this.showToast = true; 

  setTimeout(() => this.showToast = false, 3000); 

} 

 

get filteredCustomers() { 

  let filtered = this.customers; 

 

  if (this.searchText.trim()) { 

    const text = this.searchText.toLowerCase(); 

 

    filtered = filtered.filter(customer => 

      customer.customerID?.toString().includes(text) || 

      customer.firstName?.toLowerCase().includes(text) || 

      customer.lastName?.toLowerCase().includes(text) || 

      customer.email?.toLowerCase().includes(text) || 

      customer.dateOfBirth?.toLowerCase().includes(text) || 

      customer.role?.toLowerCase().includes(text) || 

      customer.address?.pincode?.toString().includes(text) 

    ); 

  } 

 

  if (this.sortColumn) { 

    filtered = filtered.slice().sort((a, b) => { 

      let aVal = a[this.sortColumn]; 

      let bVal = b[this.sortColumn]; 

 

      if (this.sortColumn === 'pincode') { 

        aVal = a.address?.pincode || ''; 

        bVal = b.address?.pincode || ''; 

      } 

 

      if (aVal < bVal) return this.sortDirection === 'asc' ? -1 : 1; 

      if (aVal > bVal) return this.sortDirection === 'asc' ? 1 : -1; 

      return 0; 

    }); 

  } 

 

  return filtered; 

} 

 

 

sortBy(column: string) { 

  if (this.sortColumn === column) { 

    this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc'; 

  } else { 

    this.sortColumn = column; 

    this.sortDirection = 'asc'; 

  } 

} 

 

 

} 
